<?php
function nm_module_tracking(): bool { return true; }
