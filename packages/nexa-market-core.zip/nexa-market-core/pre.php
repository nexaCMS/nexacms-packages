<?php
// Authenticated, CSRF-protected state changes execute before theme output.
add_action('pre','nm_handle');

if(empty($GLOBALS['adminarea'])&&!headers_sent())header('Cache-Control: no-store, private');

if(empty($GLOBALS['adminarea'])&&is_user_logged_in()){
    if(function_exists('nexa_session_enforce_idle'))nexa_session_enforce_idle('redirect');
    if(function_exists('nexa_auth_enforce_session_assurance'))nexa_auth_enforce_session_assurance('redirect');
}
