<?php
declare(strict_types=1);
namespace NexaMarket;

/** Independent, transactional domain layer. Money is always integer minor units. */
final class Engine {
    public \PDO $db;
    public function __construct(string $file) {
        $this->db = new \PDO('sqlite:'.$file, null, null, [\PDO::ATTR_ERRMODE=>\PDO::ERRMODE_EXCEPTION, \PDO::ATTR_DEFAULT_FETCH_MODE=>\PDO::FETCH_ASSOC]);
        $this->db->exec('PRAGMA foreign_keys=ON; PRAGMA busy_timeout=10000; PRAGMA journal_mode=WAL;');
        $this->db->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sellers (id INTEGER PRIMARY KEY, user_id INTEGER UNIQUE, name TEXT NOT NULL, bio TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'pending', demo INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS listings (id INTEGER PRIMARY KEY, seller_id INTEGER NOT NULL REFERENCES sellers(id), title TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL, condition TEXT NOT NULL, kind TEXT NOT NULL CHECK(kind IN ('auction','fixed')), start_price INTEGER NOT NULL CHECK(start_price>0), current_price INTEGER NOT NULL CHECK(current_price>0), increment INTEGER NOT NULL DEFAULT 100 CHECK(increment>0), reserve INTEGER NOT NULL DEFAULT 0, buy_price INTEGER NOT NULL DEFAULT 0, end_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending', winner_id INTEGER, bid_count INTEGER NOT NULL DEFAULT 0, version INTEGER NOT NULL DEFAULT 0, demo INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS bids (id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL REFERENCES listings(id), user_id INTEGER NOT NULL, amount INTEGER NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, listing_id INTEGER NOT NULL UNIQUE REFERENCES listings(id), seller_id INTEGER NOT NULL REFERENCES sellers(id), buyer_id INTEGER NOT NULL, total INTEGER NOT NULL, commission INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'awaiting_payment', created_at INTEGER NOT NULL, ship_name TEXT NOT NULL DEFAULT '', ship_email TEXT NOT NULL DEFAULT '', ship_address TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS shipments (id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL UNIQUE REFERENCES orders(id), carrier TEXT NOT NULL, tracking TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'label_created', updated_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS shipment_events (id INTEGER PRIMARY KEY, shipment_id INTEGER NOT NULL REFERENCES shipments(id), status TEXT NOT NULL, note TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY, actor INTEGER NOT NULL, action TEXT NOT NULL, object_id INTEGER NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS outbox (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, subject TEXT NOT NULL, body TEXT NOT NULL, created_at INTEGER NOT NULL, sent_at INTEGER);
CREATE TABLE IF NOT EXISTS signup_limits (key TEXT PRIMARY KEY, attempts INTEGER NOT NULL, window_start INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS watchlist (user_id INTEGER NOT NULL, listing_id INTEGER NOT NULL REFERENCES listings(id), PRIMARY KEY(user_id,listing_id));
SQL);
    }
    public function rows(string $sql, array $args=[]): array { $q=$this->db->prepare($sql);$q->execute($args);return $q->fetchAll(); }
    public function run(string $sql, array $args=[]): int { $q=$this->db->prepare($sql);$q->execute($args);return $q->rowCount(); }
    public function one(string $sql,array $args=[]): ?array { return $this->rows($sql,$args)[0]??null; }
    public function setting(string $key,string $default=''): string {return $this->one('SELECT value FROM settings WHERE key=?',[$key])['value']??$default;}
    public function set(string $key,string $value): void {$this->run('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',[$key,$value]);}
    public function tx(callable $f): mixed { $this->db->exec('BEGIN IMMEDIATE');try{$r=$f();$this->db->exec('COMMIT');return $r;}catch(\Throwable $e){$this->db->exec('ROLLBACK');throw $e;} }
    public function audit(int $actor,string $action,int $id): void {$this->run('INSERT INTO audit(actor,action,object_id,created_at) VALUES(?,?,?,?)',[$actor,$action,$id,time()]);}
    public function notify(int $user,string $subject,string $body): void {$this->run('INSERT INTO outbox(user_id,subject,body,created_at) VALUES(?,?,?,?)',[$user,$subject,$body,time()]);}
    public function seller(int $uid): ?array {return $this->one('SELECT * FROM sellers WHERE user_id=?',[$uid]);}
    public function apply(int $uid,string $name,string $bio): void {
        if($uid<1||mb_strlen_compat($name)<2||strlen($name)>90||strlen($bio)>2000)throw new \RuntimeException('Sign in and provide a shop name (2–90 characters).');
        $this->tx(function()use($uid,$name,$bio){if($this->seller($uid))throw new \RuntimeException('An application already exists.');$this->run('INSERT INTO sellers(user_id,name,bio) VALUES(?,?,?)',[$uid,$name,$bio]);$this->audit($uid,'seller.apply',(int)$this->db->lastInsertId());});
    }
    public function createListing(int $uid,array $p): int {
        $s=$this->seller($uid);if(!$s||$s['status']!=='approved')throw new \RuntimeException('An approved seller account is required.');
        $title=trim((string)($p['title']??''));$kind=$p['kind']??'';$price=(int)($p['start_price']??0);$end=(int)($p['end_at']??0);
        if(strlen($title)<3||strlen($title)>150||!in_array($kind,['auction','fixed'],true)||$price<1||$price>100000000||$end<=time()||$end>time()+90*86400)throw new \RuntimeException('Check title, price, listing type and end date (within 90 days).');
        $desc=substr(trim((string)($p['description']??'')),0,12000);$cat=substr(trim((string)($p['category']??'Other')),0,80);$cond=substr(trim((string)($p['condition']??'Used')),0,80);
        $inc=max(1,(int)($p['increment']??100));$reserve=max(0,(int)($p['reserve']??0));$buy=max(0,(int)($p['buy_price']??0));
        if($buy>0&&$buy<$price)throw new \RuntimeException('Buy now must not be below the starting price.');
        return $this->tx(function()use($s,$uid,$title,$desc,$cat,$cond,$kind,$price,$inc,$reserve,$buy,$end){
            $this->run('INSERT INTO listings(seller_id,title,description,category,condition,kind,start_price,current_price,increment,reserve,buy_price,end_at,status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',[$s['id'],$title,$desc,$cat,$cond,$kind,$price,$price,$inc,$reserve,$buy,$end,$this->setting('moderation','1')==='1'?'pending':'active']);
            $id=(int)$this->db->lastInsertId();$this->audit($uid,'listing.create',$id);return $id;
        });
    }
    public function bid(int $uid,int $id,int $amount): void {
        $this->tx(function()use($uid,$id,$amount){
            $p=$this->one('SELECT l.*,s.user_id seller_user FROM listings l JOIN sellers s ON s.id=l.seller_id WHERE l.id=?',[$id]);
            if(!$p||$p['status']!=='active'||$p['kind']!=='auction'||$p['end_at']<=time())throw new \RuntimeException('Auction is not open.');
            if($uid<1||$uid===(int)$p['seller_user'])throw new \RuntimeException('Sign in with a buyer account; self-bidding is prohibited.');
            if($p['demo'])throw new \RuntimeException('Demo listing: bidding is disabled. Create a real listing to bid.');
            $min=$p['bid_count']?(int)$p['current_price']+(int)$p['increment']:(int)$p['start_price'];
            if($amount<$min||$amount>100000000)throw new \RuntimeException('Bid is below the minimum or over the platform limit.');
            if($this->one('SELECT id FROM bids WHERE user_id=? AND created_at>? LIMIT 1',[$uid,time()-2]))throw new \RuntimeException('Please wait two seconds before bidding again.');
            $this->run('INSERT INTO bids(listing_id,user_id,amount,created_at) VALUES(?,?,?,?)',[$id,$uid,$amount,time()]);
            $end=(int)$p['end_at'];$window=(int)$this->setting('snipe_seconds','120');if($window>0&&$end-time()<$window)$end=time()+$window;
            $this->run('UPDATE listings SET current_price=?,winner_id=?,bid_count=bid_count+1,end_at=?,version=version+1 WHERE id=?',[$amount,$uid,$end,$id]);
            if($p['winner_id']&&$p['winner_id']!=$uid)$this->notify((int)$p['winner_id'],'You have been outbid','Listing #'.$id.' has a new bid.');
            $this->audit($uid,'bid.place',$id);
        });
    }
    private function makeOrder(array $p,int $uid,int $price): int {
        $fee=(int)round($price*(int)$this->setting('commission_bps','500')/10000);
        $this->run('INSERT INTO orders(listing_id,seller_id,buyer_id,total,commission,created_at) VALUES(?,?,?,?,?,?)',[$p['id'],$p['seller_id'],$uid,$price,$fee,time()]);
        $oid=(int)$this->db->lastInsertId();$this->run("UPDATE listings SET status='sold',winner_id=?,current_price=?,version=version+1 WHERE id=?",[$uid,$price,$p['id']]);
        $this->notify($uid,'Order created','Order #'.$oid.' awaits manual payment confirmation.');return $oid;
    }
    public function buy(int $uid,int $id): int {
        return $this->tx(function()use($uid,$id){
            $p=$this->one('SELECT l.*,s.user_id seller_user FROM listings l JOIN sellers s ON s.id=l.seller_id WHERE l.id=?',[$id]);
            if(!$p||$p['status']!=='active'||$p['end_at']<=time()||$uid<1||$uid===(int)$p['seller_user']||$p['demo'])throw new \RuntimeException('This listing cannot be purchased.');
            if($p['kind']==='auction'&&($p['bid_count']>0||$p['buy_price']<1))throw new \RuntimeException('Buy now is unavailable once bidding starts.');
            $id=$this->makeOrder($p,$uid,$p['kind']==='fixed'?(int)$p['start_price']:(int)$p['buy_price']);$this->audit($uid,'order.create',$id);return $id;
        });
    }
    public function settle(): int {
        return $this->tx(function(){ $n=0;foreach($this->rows("SELECT * FROM listings WHERE status='active' AND end_at<=?",[time()]) as $p){
            if($p['kind']==='auction'&&$p['winner_id']&&$p['current_price']>=$p['reserve'])$this->makeOrder($p,(int)$p['winner_id'],(int)$p['current_price']);
            else $this->run("UPDATE listings SET status='ended',version=version+1 WHERE id=?",[$p['id']]);$n++;
        }return $n;});
    }
    public function shipment(int $uid,int $order,string $carrier,string $tracking,string $status,string $note): void {
        $this->tx(function()use($uid,$order,$carrier,$tracking,$status,$note){
            $o=$this->one('SELECT o.*,s.user_id seller_user FROM orders o JOIN sellers s ON s.id=o.seller_id WHERE o.id=?',[$order]);
            if(!$o||$uid<1||$uid!==(int)$o['seller_user'])throw new \RuntimeException('Only the owning seller can update this shipment.');
            if(!in_array($o['status'],['paid','shipped','completed'],true))throw new \RuntimeException('An administrator must confirm payment before shipping.');
            $states=['label_created'=>0,'in_transit'=>1,'out_for_delivery'=>2,'delivered'=>3,'exception'=>1];
            if(!isset($states[$status])||!in_array($carrier,['postnl','dhl','ups','fedex','other'],true)||!preg_match('/^[A-Za-z0-9 ._-]{4,80}$/D',$tracking))throw new \RuntimeException('Invalid carrier, tracking number or status.');
            $old=$this->one('SELECT * FROM shipments WHERE order_id=?',[$order]);
            if($old&&$states[$status]<$states[$old['status']])throw new \RuntimeException('Shipment status cannot move backwards.');
            $this->run('INSERT INTO shipments(order_id,carrier,tracking,status,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(order_id) DO UPDATE SET carrier=excluded.carrier,tracking=excluded.tracking,status=excluded.status,updated_at=excluded.updated_at',[$order,$carrier,$tracking,$status,time()]);
            $s=$this->one('SELECT id FROM shipments WHERE order_id=?',[$order]);$this->run('INSERT INTO shipment_events(shipment_id,status,note,created_at) VALUES(?,?,?,?)',[$s['id'],$status,substr($note,0,500),time()]);
            $this->run('UPDATE orders SET status=? WHERE id=?',[$status==='delivered'?'completed':'shipped',$order]);$this->notify((int)$o['buyer_id'],'Shipment updated','Order #'.$order.': '.$status);$this->audit($uid,'shipment.update',$order);
        });
    }
    public function seed(string $file): void {
        $data=json_decode((string)file_get_contents($file),true,512,JSON_THROW_ON_ERROR);
        $this->tx(function()use($data){if($this->setting('demo_seeded')==='1')return;
            foreach($data['sellers'] as $i=>$s){$this->run("INSERT INTO sellers(name,bio,status,demo) VALUES(?,?,'approved',1)",[$s['name'],$s['bio']]);$map[$i]=(int)$this->db->lastInsertId();}
            foreach($data['listings'] as $p)$this->run("INSERT INTO listings(seller_id,title,description,category,condition,kind,start_price,current_price,increment,buy_price,end_at,status,demo) VALUES(?,?,?,?,?,?,?,?,?,?,?,'active',1)",[$map[$p['seller']],$p['title'],$p['description'],$p['category'],$p['condition'],$p['kind'],$p['price'],$p['price'],100,$p['kind']==='fixed'?$p['price']:0,time()+$p['hours']*3600]);
            $this->set('demo_seeded','1');
        });
    }
}
function mb_strlen_compat(string $s):int{return function_exists('mb_strlen')?mb_strlen($s):strlen($s);}
