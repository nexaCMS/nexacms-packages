<?php
// The supplied CMS checks login on admin pages but does not universally gate
// settings screens by role. Marketplace buyers/sellers must not inherit that access.
if(!empty($GLOBALS['adminarea'])&&is_user_logged_in()&&!current_user_can('manage_options')){
    $page=basename((string)($_SERVER['SCRIPT_NAME']??''));
    $allowed=['login.php','authenticate.php','auth-challenge.php','logout.php','forgot-password.php','reset-password.php','password-change-required.php'];
    $personal2fa=$page==='admin.php'&&($_GET['plugin_page']??'')==='nexa-2fa';
    if(!in_array($page,$allowed,true)&&!$personal2fa){
        if(($_SERVER['REQUEST_METHOD']??'GET')!=='GET'){http_response_code(403);exit('Marketplace customers and sellers cannot access CMS administration.');}
        header('Location: '.home_url('index.php?nm=account'));exit;
    }
}
