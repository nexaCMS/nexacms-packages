<?php
require_once __DIR__.'/Engine.php';
require_once __DIR__.'/guard.php';
function nm_engine(): \NexaMarket\Engine {
    static $e;if($e)return $e;
    if(!extension_loaded('pdo_sqlite'))throw new RuntimeException('Marketplace requires PHP PDO SQLite.');
    $dir=getenv('NEXA_MARKET_DATA')?:dirname(__DIR__,2).'/market-private';
    if(!is_dir($dir)&&!mkdir($dir,0700,true))throw new RuntimeException('Cannot create marketplace storage.');
    if(!is_file($dir.'/.htaccess'))file_put_contents($dir.'/.htaccess',"Require all denied\nDeny from all\n");
    if(!is_file($dir.'/index.php'))file_put_contents($dir.'/index.php',"<?php http_response_code(403); exit;");
    return $e=new \NexaMarket\Engine($dir.'/market.sqlite');
}
function nm_h($s):string{return htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');}
function nm_money(int $n):string{return nm_h(nm_engine()->setting('currency','EUR')).' '.number_format($n/100,2);}
function nm_url(array $q=[]):string{return home_url('index.php').($q?'?'.http_build_query($q):'');}
function nm_enabled(string $module):bool{return function_exists('nm_module_'.$module)&&nm_engine()->setting('enable_'.$module,'1')==='1';}
function nm_minor(string $s):int{if(!preg_match('/^\d{1,7}(?:\.\d{1,2})?$/D',$s))throw new RuntimeException('Use a positive amount with at most two decimals.');$a=explode('.',$s);return (int)$a[0]*100+(int)str_pad($a[1]??'',2,'0');}
function nm_form(string $action,string $label,string $fields=''):string{return '<form method="post">'.nexa_csrf_field().'<input type="hidden" name="nm_action" value="'.nm_h($action).'">'.$fields.'<button>'.nm_h($label).'</button></form>';}
function nm_input(string $name,string $label,string $type='text',string $value=''):string{return '<label>'.nm_h($label).'<input name="'.nm_h($name).'" type="'.nm_h($type).'" value="'.nm_h($value).'" required></label>';}
function nm_handle():void{
    if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST'||empty($_POST['nm_action']))return;
    try{
        if(($_POST['nm_action']??'')==='register'){
            if(!nexa_verify_csrf($_POST['nexa_csrf_token']??null)||nm_engine()->setting('allow_registration','0')!=='1')throw new RuntimeException('Registration is unavailable.');
            $e=nm_engine();$key=hash_hmac('sha256',(string)($_SERVER['REMOTE_ADDR']??'unknown'),(string)($GLOBALS['config']['secret_key']??''));
            $e->tx(function()use($e,$key){$r=$e->one('SELECT * FROM signup_limits WHERE key=?',[$key]);if($r&&$r['window_start']>time()-3600&&$r['attempts']>=5)throw new RuntimeException('Registration rate limit reached. Try again in an hour.');$e->run('INSERT INTO signup_limits(key,attempts,window_start) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET attempts=CASE WHEN window_start<? THEN 1 ELSE attempts+1 END,window_start=CASE WHEN window_start<? THEN excluded.window_start ELSE window_start END',[$key,time(),time()-3600,time()-3600]);});
            $user=trim((string)($_POST['username']??''));$email=trim((string)($_POST['email']??''));$pass=(string)($_POST['password']??'');
            if(!preg_match('/^[a-zA-Z0-9_-]{3,40}$/D',$user)||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)>200||empty($_POST['terms']))throw new RuntimeException('Check username, email, password and acceptance of marketplace terms.');
            $result=create_user(['user'=>$user,'email'=>$email,'pass'=>$pass,'role'=>'subscriber']);
            if(!$result)throw new RuntimeException('Account not created. The username/email may be in use or the password may not meet the CMS password policy.');
            $_SESSION['nm_flash']='Account created. Sign in using the CMS login link.';header('Location: '.nm_url(['nm'=>'account']),true,303);exit;
        }
        if(!is_user_logged_in()||!nexa_verify_csrf($_POST['nexa_csrf_token']??null))throw new RuntimeException('Sign in and reload the page before submitting.');
        $e=nm_engine();$uid=get_current_user_id();$id=(int)($_POST['id']??0);$a=(string)$_POST['nm_action'];
        switch($a){
            case 'bid':if(!nm_enabled('auctions'))throw new RuntimeException('Auctions are disabled.');$e->bid($uid,$id,nm_minor((string)($_POST['amount']??'')));break;
            case 'buy':if(!nm_enabled('sellers'))throw new RuntimeException('Purchases are disabled.');$e->buy($uid,$id);break;
            case 'apply':if(!nm_enabled('sellers'))throw new RuntimeException('Seller applications disabled.');$e->apply($uid,trim((string)$_POST['name']),trim((string)$_POST['bio']));break;
            case 'listing':
                if(!nm_enabled('sellers')||($_POST['kind']==='auction'&&!nm_enabled('auctions')))throw new RuntimeException('Listing type disabled.');
                $p=$_POST;$p['start_price']=nm_minor((string)$_POST['price']);$p['end_at']=time()+max(1,min(90,(int)$_POST['days']))*86400;$p['increment']=nm_minor((string)$_POST['increment_money']);$p['reserve']=nm_minor((string)$_POST['reserve_money']);$p['buy_price']=nm_minor((string)$_POST['buy_money']);$e->createListing($uid,$p);break;
            case 'shipment':if(!nm_enabled('tracking'))throw new RuntimeException('Tracking disabled.');$e->shipment($uid,$id,(string)$_POST['carrier'],(string)$_POST['tracking'],(string)$_POST['status'],(string)$_POST['note']);break;
            case 'address':
                $name=trim((string)($_POST['ship_name']??''));$email=trim((string)($_POST['ship_email']??''));$address=trim((string)($_POST['ship_address']??''));
                if(strlen($name)<2||strlen($name)>100||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($address)<10||strlen($address)>2000)throw new RuntimeException('Provide a valid name, email and delivery address.');
                if(!$e->run("UPDATE orders SET ship_name=?,ship_email=?,ship_address=? WHERE id=? AND buyer_id=? AND status IN ('awaiting_payment','paid')",[$name,$email,$address,$id,$uid]))throw new RuntimeException('Address cannot be updated for this order.');break;
            case 'watch':if(!$e->one('SELECT id FROM listings WHERE id=?',[$id]))throw new RuntimeException('Listing not found.');$e->run('INSERT OR IGNORE INTO watchlist(user_id,listing_id) VALUES(?,?)',[$uid,$id]);break;
            case 'unwatch':$e->run('DELETE FROM watchlist WHERE user_id=? AND listing_id=?',[$uid,$id]);break;
            default:throw new RuntimeException('Unknown marketplace action.');
        }
        do_action('nexa_market_after_action',$a,$uid,$id);
        $_SESSION['nm_flash']='Saved successfully.';
    }catch(Throwable $ex){$_SESSION['nm_flash']=$ex->getMessage();}
    header('Location: '.nm_url(array_intersect_key($_GET,array_flip(['nm','item','category','q','sort']))),true,303);exit;
}
function nm_catalog():string{
    $e=nm_engine();$q=trim((string)($_GET['q']??''));$cat=(string)($_GET['category']??'');$sort=(string)($_GET['sort']??'ending');
    $where="l.status='active'";$args=[];
    if(!nm_enabled('auctions'))$where.=" AND l.kind='fixed'";
    if($q!==''){$where.=' AND (l.title LIKE ? OR l.description LIKE ?)';$args[]='%'.$q.'%';$args[]='%'.$q.'%';}
    if($cat!==''){$where.=' AND l.category=?';$args[]=$cat;}
    if(($_GET['nm']??'')==='watchlist'){$where.=' AND l.id IN (SELECT listing_id FROM watchlist WHERE user_id=?)';$args[]=get_current_user_id();}
    $order=['ending'=>'l.end_at ASC','price'=>'l.current_price ASC','new'=>'l.id DESC'][$sort]??'l.end_at ASC';
    $page=max(1,(int)($_GET['page']??1));$offset=($page-1)*12;
    $rows=$e->rows("SELECT l.*,s.name seller_name FROM listings l JOIN sellers s ON s.id=l.seller_id WHERE $where ORDER BY $order LIMIT 13 OFFSET $offset",$args);$more=count($rows)>12;$rows=array_slice($rows,0,12);
    $h='<form class="search" method="get"><input name="q" aria-label="Search listings" placeholder="Search for your next great find" value="'.nm_h($q).'"><select aria-label="Category" name="category"><option value="">All categories</option>';
    foreach($e->rows("SELECT DISTINCT category FROM listings WHERE status='active' ORDER BY category") as $c)$h.='<option '.($cat===$c['category']?'selected':'').'>'.nm_h($c['category']).'</option>';
    $h.='</select><select aria-label="Sort" name="sort">';foreach(['ending'=>'Ending soon','price'=>'Lowest price','new'=>'Just listed'] as $k=>$v)$h.='<option value="'.$k.'" '.($sort===$k?'selected':'').'>'.$v.'</option>';
    $h.='</select><button>Search</button></form><div class="section-title"><h2>Discover something remarkable</h2><span>Independent sellers. Unexpected finds.</span></div><div class="grid">';
    foreach($rows as $p){$icon=['Electronics'=>'◉','Home & living'=>'⌂','Fashion'=>'◇','Collectibles'=>'✦','Photography'=>'▣','Outdoors'=>'△'][$p['category']]??'✧';$h.='<article class="card"><a class="art art-'.((int)$p['id']%6).'" href="'.nm_h(nm_url(['item'=>$p['id']])).'"><span>'.nm_h($icon).'</span><small>'.nm_h($p['condition']).'</small></a><div class="card-body"><div class="eyebrow">'.nm_h($p['category']).($p['demo']?' · DEMO':'').'</div><h3><a href="'.nm_h(nm_url(['item'=>$p['id']])).'">'.nm_h($p['title']).'</a></h3><p class="muted">'.nm_h($p['seller_name']).'</p><div class="price">'.nm_money((int)$p['current_price']).'<small>'.($p['kind']==='auction'?(int)$p['bid_count'].' bids':'Buy it now').'</small></div><p class="deadline" data-end="'.(int)$p['end_at'].'">Ends '.gmdate('d M H:i',(int)$p['end_at']).' UTC</p></div></article>';}
    if(!$rows)$h.='<p>No listings match. Try another search.</p>';$h.='</div><div class="pager">';
    if($page>1)$h.='<a href="'.nm_h(nm_url(array_merge($_GET,['page'=>$page-1]))).'">← Previous</a> ';
    if($more)$h.='<a href="'.nm_h(nm_url(array_merge($_GET,['page'=>$page+1]))).'">Next →</a>';
    return $h.'</div>';
}
function nm_item(int $id):string{
    $e=nm_engine();$p=$e->one('SELECT l.*,s.name seller_name,s.bio,s.user_id seller_user FROM listings l JOIN sellers s ON s.id=l.seller_id WHERE l.id=?',[$id]);
    if(!$p||($p['status']==='pending'&&!current_user_can('manage_options')&&get_current_user_id()!==(int)$p['seller_user']))return '<h2>Listing unavailable</h2>';
    $h='<a href="'.nm_h(nm_url()).'">← All listings</a><div class="detail"><div><div class="art large art-'.($id%6).'"><span>✦</span></div><h2>About this item</h2><p>'.nl2br(nm_h($p['description'])).'</p><h3>Sold by '.nm_h($p['seller_name']).'</h3><p>'.nm_h($p['bio']).'</p></div><aside><div class="eyebrow">'.nm_h($p['category']).' / '.nm_h($p['condition']).'</div><h1>'.nm_h($p['title']).'</h1><p class="price">'.nm_money((int)$p['current_price']).'</p><p>'.nm_h($p['status']).' · '.(int)$p['bid_count'].' bids · Ends '.gmdate('d M Y H:i',(int)$p['end_at']).' UTC</p>';
    if($p['reserve']>0)$h.='<p>Reserve '.($p['current_price']>=$p['reserve']?'met':'not met').'</p>';
    $hidden='<input type="hidden" name="id" value="'.$id.'">';
    if($p['demo'])$h.='<p class="notice">Sample listing — bids and purchases are disabled.</p>';
    elseif(!is_user_logged_in())$h.='<p><a href="'.nm_h(home_url('admin/login.php')).'">Sign in to bid or buy</a></p>';
    elseif($p['status']==='active'&&$p['end_at']>time()){
        if($p['kind']==='auction'&&nm_enabled('auctions')){$min=$p['bid_count']?$p['current_price']+$p['increment']:$p['start_price'];$h.=nm_form('bid','Place binding bid',$hidden.nm_input('amount','Minimum bid '.nm_money((int)$min),'text',number_format($min/100,2,'.','')));}
        if(nm_enabled('sellers')&&($p['kind']==='fixed'||($p['buy_price']>0&&$p['bid_count']==0)))$h.=nm_form('buy','Buy now · '.strip_tags(nm_money($p['kind']==='fixed'?(int)$p['start_price']:(int)$p['buy_price'])),$hidden);
    }
    if(is_user_logged_in())$h.=nm_form('watch','Save to watchlist',$hidden);
    $h.='<p class="muted">Manual payment confirmation. No automatic payment capture or marketplace payouts.</p><h3>Bid history</h3>';
    foreach($e->rows('SELECT amount,created_at FROM bids WHERE listing_id=? ORDER BY id DESC LIMIT 20',[$id]) as $b)$h.='<p>'.nm_money((int)$b['amount']).' · '.gmdate('d M H:i',(int)$b['created_at']).' UTC · private bidder</p>';
    return $h.'</aside></div>';
}
function nm_dashboard():string{
    if(!is_user_logged_in()){
        $h='<h2>Your marketplace</h2><p>Please <a href="'.nm_h(home_url('admin/login.php')).'">sign in</a>. New here? Create an account below if registration is open, or contact the administrator.</p>';
        if(nm_engine()->setting('allow_registration','0')==='1')$h.='<section class="panel"><h2>Create buyer account</h2>'.nm_form('register','Create account',nm_input('username','Username (3–40 letters, digits, hyphens or underscores)').nm_input('email','Email','email').nm_input('password','Password (CMS password policy applies)','password').'<label><input name="terms" type="checkbox" value="1" required> I accept the published marketplace terms and privacy policy.</label>').'</section>';
        return $h;
    }
    $e=nm_engine();$uid=get_current_user_id();$s=$e->seller($uid);$h='<h1>Your marketplace</h1><a href="'.nm_h(nm_url(['nm'=>'watchlist'])).'">Your watchlist →</a>';
    if(nm_enabled('sellers')){
        if(!$s)$h.='<section class="panel"><h2>Open your own shop</h2>'.nm_form('apply','Apply to sell',nm_input('name','Shop name').'<label>About your shop<textarea name="bio" maxlength="2000"></textarea></label>').'</section>';
        else {$h.='<section class="panel"><h2>'.nm_h($s['name']).'</h2><p>Seller status: '.nm_h($s['status']).'</p>';
            if($s['status']==='approved')$h.=nm_form('listing','Submit listing for review',nm_input('title','Listing title').'<label>Description<textarea name="description" maxlength="12000"></textarea></label>'.nm_input('category','Category','text','Collectibles').nm_input('condition','Condition','text','Used').'<label>Type<select name="kind"><option value="fixed">Buy now</option>'.(nm_enabled('auctions')?'<option value="auction">Auction</option>':'').'</select></label>'.nm_input('price','Starting price','text','10.00').nm_input('increment_money','Bid increment','text','1.00').nm_input('reserve_money','Reserve (0 = none)','text','0').nm_input('buy_money','Auction buy now (0 = none)','text','0').nm_input('days','Duration in days (1–90)','number','7'));
            $h.='</section><h2>Your listings</h2>';foreach($e->rows('SELECT * FROM listings WHERE seller_id=? ORDER BY id DESC',[$s['id']]) as $p)$h.='<p><a href="'.nm_h(nm_url(['item'=>$p['id']])).'">'.nm_h($p['title']).'</a> · '.nm_h($p['status']).'</p>';
        }
    }
    $h.='<h2>Orders & shipments</h2>';
    foreach($e->rows('SELECT o.*,l.title,s.user_id seller_user FROM orders o JOIN listings l ON l.id=o.listing_id JOIN sellers s ON s.id=o.seller_id WHERE o.buyer_id=? OR s.user_id=? ORDER BY o.id DESC',[$uid,$uid]) as $o){
        $h.='<section class="panel"><h3>Order #'.(int)$o['id'].' · '.nm_h($o['title']).'</h3><p>'.nm_money((int)$o['total']).' · '.nm_h($o['status']).'</p>';
        if($uid===(int)$o['buyer_id']&&in_array($o['status'],['awaiting_payment','paid'],true))$h.=nm_form('address','Save delivery details','<input type="hidden" name="id" value="'.(int)$o['id'].'">'.nm_input('ship_name','Recipient name','text',$o['ship_name']).nm_input('ship_email','Contact email','email',$o['ship_email']).'<label>Full delivery address (include country and postal code)<textarea name="ship_address" maxlength="2000" required>'.nm_h($o['ship_address']).'</textarea></label>');
        if($uid===(int)$o['seller_user']&&$o['ship_address']!=='')$h.='<p>Deliver to: '.nm_h($o['ship_name']).' · '.nm_h($o['ship_email']).'<br>'.nl2br(nm_h($o['ship_address'])).'</p>';
        if($o['status']==='awaiting_payment')$h.='<p class="notice">'.nl2br(nm_h($e->setting('payment_instructions','Contact the marketplace administrator with your order number for manual payment instructions.'))).'</p>';
        if($uid===(int)$o['seller_user'])$h.='<p>Platform fee: '.nm_money((int)$o['commission']).' · Seller net: '.nm_money((int)$o['total']-(int)$o['commission']).' (accounting only, not a payout)</p>';
        if(nm_enabled('tracking')){
            $ship=$e->one('SELECT * FROM shipments WHERE order_id=?',[$o['id']]);
            if($ship){$h.='<p>'.nm_h(strtoupper($ship['carrier'])).' · '.nm_h($ship['tracking']).' · Seller-reported tracking</p>';foreach($e->rows('SELECT * FROM shipment_events WHERE shipment_id=? ORDER BY id DESC',[$ship['id']]) as $ev)$h.='<p>'.gmdate('d M H:i',(int)$ev['created_at']).' UTC · '.nm_h($ev['status']).' — '.nm_h($ev['note']).'</p>';}
            if($uid===(int)$o['seller_user']&&in_array($o['status'],['paid','shipped','completed'],true))$h.=nm_form('shipment','Update shipment','<input type="hidden" name="id" value="'.(int)$o['id'].'"><label>Carrier<select name="carrier"><option>postnl</option><option>dhl</option><option>ups</option><option>fedex</option><option>other</option></select></label>'.nm_input('tracking','Tracking number','text',$ship['tracking']??'').'<label>Status<select name="status"><option>label_created</option><option>in_transit</option><option>out_for_delivery</option><option>delivered</option><option>exception</option></select></label><label>Note<input name="note" maxlength="500"></label>');
        }$h.='</section>';
    }
    $h.='<h2>Notifications</h2>';foreach($e->rows('SELECT * FROM outbox WHERE user_id=? ORDER BY id DESC LIMIT 30',[$uid]) as $n)$h.='<p><strong>'.nm_h($n['subject']).'</strong> — '.nm_h($n['body']).'</p>';
    return $h;
}
function nm_render():string{
    try{$e=nm_engine();$e->settle();$h='';if(isset($_SESSION['nm_flash'])){$h='<div class="notice" role="status">'.nm_h($_SESSION['nm_flash']).'</div>';unset($_SESSION['nm_flash']);}
    if(isset($_GET['item']))return $h.nm_item((int)$_GET['item']);if(($_GET['nm']??'')==='account')return $h.nm_dashboard();return $h.nm_catalog();}
    catch(Throwable $ex){error_log('Nexa Market: '.$ex->getMessage());return '<div class="notice">Marketplace unavailable. Ask an administrator to check storage permissions and PDO SQLite.</div>';}
}
add_shortcode('marketplace',fn()=>nm_render());
add_shortcode('market_account',fn()=>nm_dashboard());
