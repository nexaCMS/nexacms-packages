<?php
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
$root=dirname(__DIR__,3);require $root.'/inc.php';load_active_plugins();
if(!function_exists('nm_engine')){fwrite(STDERR,"Activate marketplace core.\n");exit(1);}
echo 'Settled '.nm_engine()->settle()." expired listings.\n";
// Explicit opt-in only. A send attempt is claimed before network I/O to avoid duplicates.
// Negative sent_at means delivery uncertain/failed; reconcile in Brevo before a manual retry.
if(in_array('--send-emails',$argv,true)){
    if(!function_exists('nexa_brevo_send')){fwrite(STDERR,"Activate and configure Nexa Brevo first.\n");exit(1);}
    $e=nm_engine();$sent=0;
    foreach($e->rows('SELECT * FROM outbox WHERE sent_at IS NULL ORDER BY id LIMIT 50') as $n){
        $account=null;foreach(get_table('users')['data'] as $u)if((int)$u['id']===(int)$n['user_id']){$account=$u;break;}
        if(!$account||!filter_var($account['email']??'',FILTER_VALIDATE_EMAIL))continue;
        $claimed=$e->tx(fn()=>$e->run('UPDATE outbox SET sent_at=? WHERE id=? AND sent_at IS NULL',[-time(),$n['id']]));if(!$claimed)continue;
        $r=nexa_brevo_send($account['email'],$n['subject'],$n['body'],['category'=>'transactional']);
        if($r['ok']){$e->run('UPDATE outbox SET sent_at=? WHERE id=?',[time(),$n['id']]);$sent++;}
        else fwrite(STDERR,'Message #'.$n['id'].': '.$r['message']." — reconcile before retry.\n");
    }
    echo 'Brevo accepted '.$sent." messages.\n";
}
