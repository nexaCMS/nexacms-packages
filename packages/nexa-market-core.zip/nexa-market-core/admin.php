<?php
add_menu_item('dashboard',['name'=>'nexa-market-core','label'=>' Marketplace','link'=>'admin.php?plugin_page=nexa-market-core'],60);
add_action('nexa_admin',function(){
    if(($_GET['plugin_page']??'')!=='nexa-market-core'||!current_user_can('manage_options'))return;
    try{$e=nm_engine();
    if(($_SERVER['REQUEST_METHOD']??'GET')==='POST'){
        if(!nexa_verify_csrf($_POST['nexa_csrf_token']??null))throw new RuntimeException('Invalid CSRF token.');
        $id=(int)($_POST['id']??0);$a=$_POST['market_admin']??'';$uid=get_current_user_id();
        $e->tx(function()use($e,$id,$a,$uid){
            if($a==='approve_seller')$e->run("UPDATE sellers SET status='approved' WHERE id=? AND demo=0",[$id]);
            elseif($a==='suspend_seller'){$e->run("UPDATE sellers SET status='suspended' WHERE id=?",[$id]);$e->run("UPDATE listings SET status='paused' WHERE seller_id=? AND status IN ('active','pending')",[$id]);}
            elseif($a==='approve_listing')$e->run("UPDATE listings SET status='active' WHERE id=? AND status='pending' AND end_at>? AND seller_id IN (SELECT id FROM sellers WHERE status='approved')",[$id,time()]);
            elseif($a==='reject_listing')$e->run("UPDATE listings SET status='rejected' WHERE id=? AND status='pending'",[$id]);
            elseif($a==='confirm_payment')$e->run("UPDATE orders SET status='paid' WHERE id=? AND status='awaiting_payment'",[$id]);
            else throw new RuntimeException('Unsupported action.');
            $e->audit($uid,$a,$id);
        });echo '<p class="alert alert-success">Action processed.</p>';
    }
    $btn=static function($a,$id,$text){return '<form method="post" style="display:inline">'.nexa_csrf_field().'<input type="hidden" name="id" value="'.(int)$id.'"><button name="market_admin" value="'.$a.'">'.$text.'</button></form>';};
    echo '<h1>Marketplace operations</h1><p><a href="admin.php?plugin_page=nexa-market-setup">Setup & settings</a> · <a href="'.nm_h(nm_url()).'">Visit market</a></p>';
    echo '<h2>Sellers</h2><table class="table"><tr><th>Shop</th><th>Account</th><th>Status</th><th>Action</th></tr>';
    foreach($e->rows('SELECT * FROM sellers ORDER BY id DESC') as $s)echo '<tr><td>'.nm_h($s['name']).'</td><td>'.($s['demo']?'Demo (no login)':(int)$s['user_id']).'</td><td>'.nm_h($s['status']).'</td><td>'.(!$s['demo']?$btn('approve_seller',$s['id'],'Approve').$btn('suspend_seller',$s['id'],'Suspend'):'').'</td></tr>';echo '</table>';
    echo '<h2>Listings awaiting review</h2>';foreach($e->rows("SELECT * FROM listings WHERE status='pending'") as $p)echo '<p><a href="'.nm_h(nm_url(['item'=>$p['id']])).'">'.nm_h($p['title']).'</a> '.$btn('approve_listing',$p['id'],'Publish').$btn('reject_listing',$p['id'],'Reject').'</p>';
    echo '<h2>Orders</h2><p>Confirm only after independently verifying receipt of payment. Fees below are accounting records; this suite does not hold funds or pay sellers.</p><table class="table"><tr><th>Order</th><th>Buyer / seller</th><th>Total / fee</th><th>Status</th></tr>';
    foreach($e->rows('SELECT * FROM orders ORDER BY id DESC LIMIT 200') as $o)echo '<tr><td>#'.(int)$o['id'].'</td><td>'.(int)$o['buyer_id'].' / '.(int)$o['seller_id'].'</td><td>'.nm_money((int)$o['total']).' / '.nm_money((int)$o['commission']).'</td><td>'.nm_h($o['status']).' '.($o['status']==='awaiting_payment'?$btn('confirm_payment',$o['id'],'Confirm manual payment'):'').'</td></tr>';echo '</table>';
    echo '<h2>Recent audit trail</h2>';foreach($e->rows('SELECT * FROM audit ORDER BY id DESC LIMIT 30') as $a)echo '<p>'.gmdate('Y-m-d H:i',(int)$a['created_at']).' UTC · user '.(int)$a['actor'].' · '.nm_h($a['action']).' #'.(int)$a['object_id'].'</p>';
    }catch(Throwable $x){echo '<div class="alert alert-danger">'.nm_h($x->getMessage()).'</div>';}
});
