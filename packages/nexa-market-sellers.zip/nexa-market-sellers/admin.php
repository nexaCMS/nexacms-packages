<?php
add_menu_item('dashboard',['name'=>'nexa-market-sellers','label'=>' Market Multi-seller','link'=>'admin.php?plugin_page=nexa-market-sellers'],62);
add_action('nexa_admin',function(){if(($_GET['plugin_page']??'')!=='nexa-market-sellers'||!current_user_can('manage_options'))return;
echo '<h2>Market Multi-seller</h2><p>Manage this module in <a href="admin.php?plugin_page=nexa-market-setup">Marketplace setup</a>. Disable it there without deleting its data.</p>';});
