<?php
function nm_module_sellers(): bool { return true; }
