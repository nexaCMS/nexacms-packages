<?php
// Core drives all challenge callbacks. No endpoint, session grant or redirect override here.
