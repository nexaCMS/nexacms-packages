<?php
function nx2_key(): string {
    $k=base64_decode((string)(nx2_configuration()['key']??''),true);
    if ($k===false || strlen($k)!==32) throw new RuntimeException('2FA encryption key is unavailable.');
    return $k;
}
function nx2_seal(array $state): string {
    $nonce=random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
    return base64_encode($nonce.sodium_crypto_secretbox(json_encode($state,JSON_THROW_ON_ERROR),$nonce,nx2_key()));
}
function nx2_open(string $sealed): array {
    $raw=base64_decode($sealed,true);
    if ($raw===false || strlen($raw)<40) throw new RuntimeException('Invalid encrypted 2FA record.');
    $plain=sodium_crypto_secretbox_open(substr($raw,24),substr($raw,0,24),nx2_key());
    if ($plain===false) throw new RuntimeException('2FA record cannot be decrypted. Restore the correct deployment key.');
    $state=json_decode($plain,true,512,JSON_THROW_ON_ERROR);
    if (!is_array($state)) throw new RuntimeException('Invalid 2FA state.');
    return $state;
}
function nx2_b32(string $raw): string {
    $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$bits='';$out='';
    foreach (str_split($raw) as $c) $bits.=str_pad(decbin(ord($c)),8,'0',STR_PAD_LEFT);
    foreach (str_split($bits,5) as $chunk) $out.=$alphabet[bindec(str_pad($chunk,5,'0'))];
    return $out;
}
function nx2_unb32(string $text): string {
    $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$bits='';$out='';
    foreach(str_split(strtoupper($text)) as $c) { $v=strpos($alphabet,$c); if($v===false) throw new RuntimeException('Invalid TOTP secret.'); $bits.=str_pad(decbin($v),5,'0',STR_PAD_LEFT); }
    foreach(str_split($bits,8) as $b) if(strlen($b)===8) $out.=chr(bindec($b));
    return $out;
}
function nx2_totp(string $secret,int $step,int $digits=6): string {
    $counter=pack('N2',intdiv($step,4294967296),$step%4294967296);
    $mac=hash_hmac('sha1',$counter,nx2_unb32($secret),true);$offset=ord($mac[19])&15;
    $n=unpack('N',substr($mac,$offset,4))[1]&0x7fffffff;
    return str_pad((string)($n%(10**$digits)),$digits,'0',STR_PAD_LEFT);
}
function nx2_match_totp(string $secret,string $code,int $last,int $now): ?int {
    if (!preg_match('/^[0-9]{6}$/D',$code)) return null;
    $current=intdiv($now,30);
    // Check newest first; persist the used timestep under the account lock.
    foreach ([$current+1,$current,$current-1] as $step) if ($step>$last && hash_equals(nx2_totp($secret,$step),$code)) return $step;
    return null;
}
function nx2_recovery(): array {
    $plain=[];$hashes=[];
    for($i=0;$i<10;$i++){ $c=bin2hex(random_bytes(10));$plain[]=$c;$hashes[]=hash('sha256',$c); }
    return [$plain,$hashes];
}
function nx2_recovery_consume(array &$state,string $code): bool {
    $code=strtolower(str_replace([' ','-'],'',$code));
    if (!preg_match('/^[a-f0-9]{20}$/D',$code)) return false;
    $hash=hash('sha256',$code);
    foreach($state['recovery'] as $i=>$saved) if(hash_equals($saved,$hash)){unset($state['recovery'][$i]);$state['recovery']=array_values($state['recovery']);return true;}
    return false;
}
