<?php
/** Nexa 2FA: core owns authentication; this plugin never grants a login session. */
if (!function_exists('get_setting')) return;
require_once __DIR__.'/hosting.php';
require_once __DIR__.'/configuration.php';
require_once __DIR__.'/storage.php';
require_once __DIR__.'/crypto.php';
require_once __DIR__.'/devices.php';
require_once __DIR__.'/compatibility.php';
require_once __DIR__.'/provider.php';
if (function_exists('nexa_register_auth_challenge_provider') && function_exists('nexa_auth_decide_all') && function_exists('nexa_auth_enforce_session_assurance')) {
    nexa_register_auth_challenge_provider('nexa-2fa', [
        'decide'=>'nx2_decide', 'render'=>'nx2_render', 'verify'=>'nx2_verify', 'session_check'=>'nx2_session_check'
    ]);
}
function nx2_policy(): array {
    return nx2_network(function () {
        $p = json_decode((string)get_setting('nx2_policy', '{}'), true);
        return array_merge(['scope'=>'optional','methods'=>['totp'],'version'=>'initial','armed'=>false,'trusted_devices'=>true], is_array($p) ? $p : []);
    });
}
function nx2_required(array $ctx, array $state, array $policy): bool {
    return !empty($state['requested']) || !empty($state['factor']) || $policy['scope'] === 'all'
        || ($policy['scope'] === 'admins' && in_array($ctx['role'], ['admin','super_admin'], true));
}
function nx2_ctx(): array {
    return ['user_id'=>get_current_user_id(),'username'=>(string)($_SESSION['name'] ?? ''),
        'role'=>(string)($_SESSION['admin_type'] ?? ''),
        'realm'=>!empty($_SESSION['nexa_site_db_user']) ? 'site:'.(int)$_SESSION['nexa_site_db_user'] : 'main',
        'site_id'=>(int)($_SESSION['nexa_admin_site_id'] ?? 0)];
}
function nx2_account(array $ctx): array {
    $a = nx2_network(fn()=>nexa_auth_refetch_account($ctx));
    if (!$a || (int)$a['id'] !== (int)$ctx['user_id'] || strcasecmp((string)$a['user'], (string)$ctx['username']) !== 0)
        throw new RuntimeException('Account identity mismatch: session user ID '.(int)$ctx['user_id'].' / login '.(string)$ctx['username'].' / realm '.(string)$ctx['realm'].'. '.(!$a?'No account was returned by the core realm lookup.':'Core returned user ID '.(int)($a['id']??0).' / login '.(string)($a['user']??'').'.').' Sign out and sign back in; if this persists, send these non-secret details to your CMS developer. No identity check was bypassed.');
    return $a;
}
function nx2_password(array $ctx, string $password): bool {
    return $password !== '' && password_verify($password, (string)(nx2_account($ctx)['pass'] ?? ''));
}

// Copy availability requirement to the active site's settings, preserving other providers.
// Installing/enabling this provider in every login context is a deployment requirement.
if (function_exists('nexa_auth_required_providers') && !empty(nx2_policy()['armed']) && !nx2_testing_active()) {
    nx2_arm();
}
// No caching of enrollment secrets, recovery codes or challenge pages.
if (!headers_sent() && (!empty($_SESSION['nexa_auth_pending']) || ($_GET['plugin_page'] ?? '')==='nexa-2fa')) {
    header('Cache-Control: no-store, private');
    header('Pragma: no-cache');
    header('Referrer-Policy: no-referrer');
}
