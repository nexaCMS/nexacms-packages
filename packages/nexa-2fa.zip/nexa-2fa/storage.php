<?php
function nx2_network(callable $fn) {
    if (!function_exists('nexa_network_call')) return $fn();
    // Core switches DB/prefix, but settings are a separate request-global cache.
    return nexa_network_call(function() use($fn) {
        $saved=$GLOBALS['settings'] ?? [];
        try { loadsettings(); return $fn(); }
        finally { $GLOBALS['settings']=$saved; }
    });
}
function nx2_ready(): string {
    if (!function_exists('nexa_auth_decide_all') || !function_exists('nexa_auth_enforce_session_assurance')) return 'NexaCMS 1.29.1 or later is required.';
    if (!function_exists('flock')) return 'PHP file locking is unavailable; this deployment is not supported.';
    if (!extension_loaded('sodium')) return 'PHP sodium is required.';
    try { $c=nx2_configuration(); } catch(Throwable $e) { return 'Selected 2FA configuration cannot be loaded or fails private-file checks. Use Hosting diagnostics; restore the ORIGINAL key if needed.'; }
    $key = base64_decode((string)($c['key']??''), true);
    if ($key === false || strlen($key) !== 32) return 'Configure a random 32-byte key using environment variables or Shared-hosting setup below.';
    $lockDir=(string)($c['lock_dir']??'');
    if ($lockDir==='') return 'Configure the lock directory. Environment mode requires NEXA_2FA_LOCK_DIR.';
    $dir = realpath($lockDir);
    if (!$dir || !is_dir($dir) || !is_writable($dir)) return 'The configured 2FA lock directory does not exist or is not writable by PHP.';
    if(nx2_mode()==='external') return ''; // external configuration was strictly validated by its loader.
    if(nx2_mode()==='local') {
        $local=nx2_local_dir();
        if(($c['protection']??'')!=='browser-probe-v1' || realpath($local.'/locks')!==$dir) return 'Local storage setup is incomplete or its lock path changed.';
        if(!is_file($local.'/.htaccess') || nx2_normalize_rules(file_get_contents($local.'/.htaccess'))!==nx2_normalize_rules(nx2_deny_rules())) return 'Local storage protection is missing or changed. Restore its original .htaccess; do not regenerate the key.';
        $permissionOverride=nx2_permission_exception_active();
        if(!$permissionOverride && ((fileperms($local.'/config.php')&0022)!==0 || (fileperms($local.'/.htaccess')&0022)!==0)) return 'Local configuration/protection files must not be group/world writable (use 0600 or 0644).';
        if(!$permissionOverride && ((fileperms($local)&0022)!==0 || (fileperms($dir)&0022)!==0)) return 'Local 2FA folders must not be group/world writable (use 0700 or 0755).';
        return '';
    }
    if ((fileperms($dir) & 0077)!==0) return 'Restrict the 2FA lock directory to its owner (permissions 0700).';
    $root = realpath((string)($GLOBALS['config']['abs'] ?? dirname(__DIR__, 3)));
    $docRaw=(string)($_SERVER['DOCUMENT_ROOT'] ?? '');
    $doc = $docRaw!=='' ? realpath($docRaw) : false;
    foreach ([$root,$doc] as $base) if ($base && ($dir === $base || str_starts_with($dir, rtrim($base,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR))) return 'The lock directory must be outside the CMS and document root.';
    return '';
}
function nx2_mutex(callable $fn) {
    static $depth=0;
    if($depth>0) return $fn();
    for($attempt=0;$attempt<3;$attempt++) {
        $error=nx2_ready();if($error!=='') throw new RuntimeException($error);
        $path=realpath((string)nx2_configuration()['lock_dir']).'/nexa-2fa.lock';
        $fh=fopen($path,'c');if(!$fh)throw new RuntimeException('Cannot open 2FA lock.');@chmod($path,0600);
        if(!flock($fh,LOCK_EX)){fclose($fh);throw new RuntimeException('Cannot acquire 2FA lock.');}
        // A migration may have completed while this request waited on the old lock.
        try{$current=realpath((string)nx2_configuration()['lock_dir']).'/nexa-2fa.lock';}
        catch(Throwable $e){flock($fh,LOCK_UN);fclose($fh);throw $e;}
        if($current!==$path){flock($fh,LOCK_UN);fclose($fh);continue;}
        $depth++;try{return $fn();}finally{$depth--;flock($fh,LOCK_UN);fclose($fh);}
    }
    throw new RuntimeException('2FA storage selection changed repeatedly. Retry after migration.');
}
function nx2_lock(callable $fn) { return nx2_mutex(fn()=>nx2_network($fn)); }
function nx2_ensure(): void {
    if (!table_exists('nx2_accounts')) create_table('nx2_accounts',['identity_key','sealed']);
    if (!table_exists('nx2_audit')) create_table('nx2_audit',['identity_key','realm','user_id','username','event','created_at']);
}
function nx2_identity(array $ctx): string {
    if (empty($ctx['user_id']) || empty($ctx['username']) || !preg_match('/^(main|site:[1-9][0-9]*)$/', (string)$ctx['realm'])) throw new RuntimeException('Invalid 2FA identity.');
    return hash('sha256', $ctx['realm']."\0".(string)$ctx['user_id']."\0".strtolower($ctx['username']));
}
function nx2_row(array $ctx): array {
    nx2_ensure();
    $rows = query('SELECT * FROM nx2_accounts WHERE identity_key = ?', [nx2_identity($ctx)]);
    if (count($rows) > 1) throw new RuntimeException('Duplicate 2FA account records; owner intervention required.');
    $row = $rows[0] ?? [];
    $state = $row ? nx2_open((string)$row['sealed']) : [];
    return [$row, array_merge(['trusted_days'=>30,'devices'=>[],'requested'=>false,'factor'=>'','secret'=>'','email'=>'','recovery'=>[],
        'last_step'=>-1,'epoch'=>bin2hex(random_bytes(12)),'attempts'=>0,'window'=>0,'sent'=>0,'send_window'=>0,'last_send'=>0,'email_nonce'=>''],$state)];
}
function nx2_save(array $ctx, array $row, array $state): void {
    $data = ['identity_key'=>nx2_identity($ctx),'sealed'=>nx2_seal($state)];
    if ($row) $data['id'] = $row['id'];
    $result = update_table('nx2_accounts',$data,$row ? 'update' : 'insert');
    // Read back: the universal helpers may return a driver-specific write result.
    $rows = query('SELECT * FROM nx2_accounts WHERE identity_key = ?', [$data['identity_key']]);
    if (count($rows) !== 1 || (string)$rows[0]['sealed'] !== $data['sealed']) throw new RuntimeException('2FA state write could not be confirmed.');
}
function nx2_audit(array $ctx, string $event): void {
    update_table('nx2_audit',['identity_key'=>nx2_identity($ctx),'realm'=>$ctx['realm'],'user_id'=>(string)$ctx['user_id'],'username'=>$ctx['username'],'event'=>$event,'created_at'=>gmdate('Y-m-d H:i:s')],'insert');
    // Retain approximately 90 days, no OTPs, email bodies or IP addresses.
    query('DELETE FROM nx2_audit WHERE created_at < ?', [gmdate('Y-m-d H:i:s',time()-90*86400)]);
}
function nx2_read(array $ctx): array { return nx2_lock(fn()=>nx2_row($ctx)[1]); }
function nx2_fail(array $ctx, array $row, array &$state, string $message): array {
    nx2_save($ctx,$row,$state); nx2_audit($ctx,'verification_failed');
    return ['ok'=>false,'error'=>$message];
}

function nx2_store_policy(array $p): void {
    loadsettings();
    $value=json_encode($p,JSON_THROW_ON_ERROR);
    set_setting('nx2_policy',$value);
    $rows=query('SELECT value FROM settings WHERE setting = ?', ['nx2_policy']);
    if(count($rows)!==1 || (string)$rows[0]['value']!==$value) throw new RuntimeException('Policy write could not be confirmed. Check settings storage.');
}
function nx2_arm(): void {
    // Reload the active site's settings cache before core writes a setting.
    loadsettings();
    if(in_array('nexa-2fa',nexa_auth_required_providers(),true)) return;
    nx2_mutex(function(){
        loadsettings();
        $ids=nexa_auth_required_providers();
        if(!in_array('nexa-2fa',$ids,true)){$ids[]='nexa-2fa';nexa_auth_set_required_providers($ids);}
        $rows=query('SELECT value FROM settings WHERE setting = ?', ['nexa_auth_required_providers']);
        $stored=json_decode((string)($rows[0]['value']??'[]'),true);
        if(count($rows)!==1 || !is_array($stored) || !in_array('nexa-2fa',$stored,true)) throw new RuntimeException('Required-provider availability marker could not be persisted.');
    });
}
