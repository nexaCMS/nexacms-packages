<?php
/** Environment mode takes precedence as a complete pair; no silent mixing. */
function nx2_local_dir(): string { return rtrim((string)($GLOBALS['config']['abs'] ?? dirname(__DIR__,3)), '/\\').'/content/nexa-2fa-private'; }
function nx2_mode(): string {
    if ((string)getenv('NEXA_2FA_KEY')!=='' || (string)getenv('NEXA_2FA_LOCK_DIR')!=='') return 'environment';
    if(nx2_external_path()!=='') return 'external';
    return is_file(nx2_local_dir().'/config.php') ? 'local' : 'unconfigured';
}
function nx2_configuration(): array {
    if(nx2_mode()==='environment') return ['key'=>(string)getenv('NEXA_2FA_KEY'),'lock_dir'=>(string)getenv('NEXA_2FA_LOCK_DIR')];
    if(nx2_mode()==='external') { $path=nx2_external_path();if(basename($path)!=='config.php')throw new RuntimeException('Invalid external configuration selector.');return nx2_external_check(dirname($path)); }
    if(nx2_mode()==='local') return nx2_read_generated_config(nx2_local_dir().'/config.php');
    return ['key'=>'','lock_dir'=>''];
}
function nx2_deny_rules(): string {
    return "# Nexa 2FA private storage. Never remove these rules.\nErrorDocument 403 \"Nexa 2FA private storage: access denied.\"\nErrorDocument 404 \"Not found.\"\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n";
}
function nx2_private_config_source(string $key): string {
    return "<?php\n// PRIVATE: back up securely; never replace this key on an enrolled installation.\nif (!defined('NEXA_2FA_CONFIG_READ')) { http_response_code(404); exit; }\nreturn [\n'version'=>1,\n'key'=>".var_export($key,true).",\n'lock_dir'=>__DIR__.'/locks',\n'protection'=>'browser-probe-v1',\n];\n";
}
function nx2_setup_allowed(): void {
    if(!is_user_logged_in() || !in_array((string)($_SESSION['admin_type']??''),['admin','super_admin'],true)
        || !empty($_SESSION['nexa_admin_site_id']) || !empty($_SESSION['nexa_site_db_user']) || !empty($GLOBALS['nexa_in_site_admin']))
        throw new RuntimeException('Shared-hosting setup is restricted to a main-site administrator.');
    if(nx2_mode()!=='unconfigured') throw new RuntimeException('A configuration already exists or an environment override is present. No key will be replaced.');
    if(!function_exists('nexa_auth_decide_all') || !function_exists('nexa_auth_enforce_session_assurance')) throw new RuntimeException('NexaCMS 1.29.1+ is required.');
    if(!extension_loaded('sodium')) throw new RuntimeException('PHP sodium is required; ask your host to enable it.');
    if(!empty(nx2_policy()['armed'])) throw new RuntimeException('This installation has already armed 2FA. Restore the ORIGINAL key/configuration; do not generate another key.');
    $has=nx2_network(fn()=>table_exists('nx2_accounts') && count_records('nx2_accounts')>0);
    if($has) throw new RuntimeException('Existing 2FA account data was found. Restore the original key; automatic setup refuses to replace it.');
}
function nx2_setup_password(array $ctx,string $password): void {
    $t=$_SESSION['nx2_setup_attempts']??['at'=>time(),'count'=>0];
    if(time()-(int)$t['at']>=900) $t=['at'=>time(),'count'=>0];
    if($t['count']>=5) throw new RuntimeException('Setup password attempt limit reached. Wait 15 minutes.');
    $t['count']++;$_SESSION['nx2_setup_attempts']=$t;
    if(!nx2_password($ctx,$password)) throw new RuntimeException('Current password is incorrect.');
}
function nx2_setup_prepare(array $ctx,string $password): void {
    nx2_setup_allowed();nx2_setup_password($ctx,$password);
    $dir=nx2_local_dir();$content=dirname($dir);
    if(!is_dir($content) || !is_writable($content)) throw new RuntimeException('The CMS content folder must be writable by PHP.');
    if(is_link($dir)) throw new RuntimeException('The private directory must not be a symlink.');
    if(!is_dir($dir) && !mkdir($dir,0700)) throw new RuntimeException('Could not create the private folder.');
    @chmod($dir,0700);
    $ht=$dir.'/.htaccess';
    if(is_file($ht) && nx2_normalize_rules(file_get_contents($ht))!==nx2_normalize_rules(nx2_deny_rules())) throw new RuntimeException('A different private-folder .htaccess already exists. Have your developer review it; setup will not overwrite it.');
    if(file_put_contents($ht,nx2_deny_rules(),LOCK_EX)===false) throw new RuntimeException('Cannot write private-folder protection.');
    $index="<?php http_response_code(404); exit;\n";
    if(file_put_contents($dir.'/index.php',$index,LOCK_EX)===false) throw new RuntimeException('Cannot create the private-folder index guard.');
    $locks=$dir.'/locks';
    if(!is_dir($locks) && !mkdir($locks,0700)) throw new RuntimeException('Cannot create the lock directory.');
    @chmod($locks,0700);
    $h=fopen($locks.'/setup.lock','c');
    if(!$h) throw new RuntimeException('PHP cannot open the lock test file.');
    $locked=flock($h,LOCK_EX|LOCK_NB);if($locked) flock($h,LOCK_UN);fclose($h);
    if(!$locked) throw new RuntimeException('File locking is unavailable on this host.');
    nx2_setup_cleanup();
    $token=bin2hex(random_bytes(24));$name='probe-'.bin2hex(random_bytes(12)).'.txt';
    $public='nexa-2fa-'.$name;
    if(file_put_contents($content.'/'.$public,$token,LOCK_EX)===false || file_put_contents($dir.'/'.$name,$token,LOCK_EX)===false) throw new RuntimeException('Cannot write browser protection probes.');
    @chmod($content.'/'.$public,0644); // Public marker is intentionally non-secret.
    $_SESSION['nx2_setup']=['name'=>$name,'public'=>$public,'token'=>$token,'expires'=>time()+600,'identity'=>nx2_identity($ctx)];
}
function nx2_setup_cleanup(): void {
    $d=$_SESSION['nx2_setup']??[];
    foreach(['public','name'] as $field) {
        $name=$d[$field]??'';
        if(is_string($name) && preg_match('/^(nexa-2fa-)?probe-[a-f0-9]{24}\.txt$/D',$name)) {
            $path=$field==='public'?dirname(nx2_local_dir()).'/'.$name:nx2_local_dir().'/'.$name;
            if(is_file($path)) @unlink($path);
        }
    }
    unset($_SESSION['nx2_setup']);
}
function nx2_setup_finish(array $ctx,array $post): void {
    nx2_setup_allowed();$d=$_SESSION['nx2_setup']??[];
    if(empty($d) || ($d['identity']??'')!==nx2_identity($ctx) || (int)$d['expires']<time()) {nx2_setup_cleanup();throw new RuntimeException('Setup expired. Start again.');}
    // The authenticated operator's same-origin browser, not a server-side URL fetch,
    // reports the probe result. This avoids SSRF and supports hosting bot cookies.
    $token=is_string($post['nx2_probe_token']??null)?$post['nx2_probe_token']:'';
    $status=(string)($post['nx2_private_status']??'');
    if(!hash_equals($d['token'],$token) || !in_array($status,['403','404'],true) || ($post['nx2_public_ok']??'')!=='yes') throw new RuntimeException('Protection was not verified. No encryption key was created.');
    if(nx2_normalize_rules(file_get_contents(nx2_local_dir().'/.htaccess'))!==nx2_normalize_rules(nx2_deny_rules())) throw new RuntimeException('Protection rules changed. Start again.');
    $path=nx2_local_dir().'/config.php';
    $key=base64_encode(random_bytes(32));
    // Exclusive creation: concurrent setup requests cannot overwrite a key.
    $fh=fopen($path,'x');
    if(!$fh) throw new RuntimeException('Configuration already exists or cannot be created. Nothing was overwritten.');
    $source=nx2_private_config_source($key);$written=fwrite($fh,$source);fflush($fh);fclose($fh);@chmod($path,0600);
    if($written!==strlen($source)) throw new RuntimeException('Configuration write was incomplete. Have your developer recover this file before continuing.');
    nx2_setup_cleanup();
    if(nx2_ready()!=='') throw new RuntimeException('Configuration created but checks did not pass: '.nx2_ready());
}
function nx2_setup_screen(array $ctx): void {
    $notice='';
    try {
        if(($_SERVER['REQUEST_METHOD']??'')==='POST' && isset($_POST['nx2_setup_action'])) {
            if(!nexa_verify_csrf(is_string($_POST['nx2_csrf']??null)?$_POST['nx2_csrf']:'')) throw new RuntimeException('Security check failed. Reload the page.');
            if($_POST['nx2_setup_action']==='prepare') nx2_setup_prepare($ctx,is_string($_POST['nx2_password']??null)?$_POST['nx2_password']:'');
            elseif($_POST['nx2_setup_action']==='finish') {nx2_setup_finish($ctx,$_POST);$notice='Shared-hosting setup complete. Your key was generated and saved privately. Reload this page to enroll; back up content/nexa-2fa-private/config.php securely using File Manager.';}
        }
    } catch(Throwable $e) {$notice=$e instanceof RuntimeException?$e->getMessage():'Setup failed. Check file permissions and PHP configuration.';}
    if($notice!=='') echo '<div class="alert alert-info">'.esc_html($notice).'</div>';
    echo '<h2>Hosting configuration</h2><p>Active mode: <strong>'.esc_html(nx2_mode()).'</strong>. Environment variables take precedence as a pair; local configuration never overrides them.</p>';
    echo '<h3>Option A — environment mode</h3><p>Set NEXA_2FA_KEY and NEXA_2FA_LOCK_DIR through your hosting/PHP configuration. The lock directory must be private and outside the website. Existing environment-mode installations keep working.</p>';
    echo '<h3>Option B — shared-hosting / File Manager mode</h3><p>No core edits or terminal access needed. Setup creates a protected content/nexa-2fa-private folder, verifies browser access restrictions, then creates a random key in a guarded PHP file. Keep a private backup; never replace an existing key. Requires Apache-compatible .htaccess protection and PHP sodium.</p>';
    try {nx2_setup_allowed();} catch(Throwable $e) {echo '<p class="alert alert-warning">'.esc_html($e->getMessage()).'</p>';return;}
    $d=$_SESSION['nx2_setup']??[];
    if(!empty($d) && (int)$d['expires']>=time() && $d['identity']===nx2_identity($ctx)) {
        echo '<p>Step 2: click Verify protection. Your browser must read the public test marker and receive HTTP 403 or 404 for the identical marker inside the private folder. Redirects, network errors and HTTP 500 do not count as protection. If verification fails, do not bypass it.</p><button type="button" class="btn btn-primary" id="nx2-probe">Verify protection and finish setup</button><p id="nx2-probe-result" role="status"></p><form method="post" id="nx2-finish" style="display:none">';
        echo nexa_csrf_field();
        echo '<input name="nx2_csrf" value="'.esc_attr(nexa_csrf_token()).'"><input name="nx2_setup_action" value="finish"><input name="nx2_probe_token" value="'.esc_attr($d['token']).'"><input name="nx2_public_ok" value="yes"><input name="nx2_private_status" id="nx2-private-status"></form>';
        $base=parse_url(baseurl(),PHP_URL_PATH)?:'';$base=rtrim($base,'/');
        $payload=json_encode(['public'=>$base.'/content/'.$d['public'],'private'=>$base.'/content/nexa-2fa-private/'.$d['name'],'token'=>$d['token']],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        echo '<script>(function(){const p='.$payload.';const b=document.getElementById("nx2-probe"),o=document.getElementById("nx2-probe-result");b.onclick=async function(){b.disabled=true;o.textContent="Checking public and private test files…";try{const opts={cache:"no-store",credentials:"same-origin",redirect:"error"};const a=await fetch(p.public,opts);if(a.status!==200||(await a.text()).trim()!==p.token)throw new Error("Public marker could not be verified. A hosting bot check, redirect or incorrect base URL may be interfering.");const r=await fetch(p.private,opts);const body=await r.text();if(![403,404].includes(r.status)||body.includes(p.token))throw new Error("Private-folder protection failed (HTTP "+r.status+"). No key has been created.");document.getElementById("nx2-private-status").value=String(r.status);document.getElementById("nx2-finish").submit();}catch(e){o.textContent=e.message+" No key was created. Ask your host/developer to review the protection; do not remove this check.";b.disabled=false;}};})();</script>';
    } else {
        echo '<p>Step 1: confirm your password to prepare the protected folder. No encryption key is generated until the browser test succeeds.</p><form method="post">';echo nexa_csrf_field();
        echo '<input type="hidden" name="nx2_csrf" value="'.esc_attr(nexa_csrf_token()).'"><label>Current password <input class="form-control" type="password" name="nx2_password" autocomplete="current-password" required></label><button class="btn btn-primary" name="nx2_setup_action" value="prepare">Prepare shared-hosting setup</button></form>';
    }
}
