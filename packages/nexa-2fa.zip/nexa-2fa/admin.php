<?php
if(empty($GLOBALS['adminarea'])) return;
add_menu_item('dashboard',['name'=>'nexa-2fa','class'=>(($_GET['plugin_page']??'')==='nexa-2fa'?'active':''),
    'icon'=>'fa fa-shield fa-fw','label'=>' Two-factor authentication','link'=>'admin.php?plugin_page=nexa-2fa'],61);
foreach(['nexa_admin','di_admin','up_admin'] as $hook) add_action($hook,'nx2_admin');
function nx2_reauth(array $ctx,array $row,array &$s,string $password,string $code): bool {
    $now=time();if($now-(int)$s['window']>=900){$s['window']=$now;$s['attempts']=0;}
    if($s['attempts']>=5) throw new RuntimeException('Account rate limit reached. Wait 15 minutes from the first attempt.');
    $s['attempts']++;
    $ok=nx2_password($ctx,$password);
    if($ok && $s['factor']) {
        if(!nx2_recovery_consume($s,$code)) {
            $step=$s['factor']==='totp'?nx2_match_totp($s['secret'],$code,(int)$s['last_step'],$now):null;
            $ok=$step!==null;
            if($ok) $s['last_step']=$step;
        }
    }
    if($ok) $s['attempts']=0;
    nx2_save($ctx,$row,$s);
    if(!$ok){nx2_audit($ctx,'management_reauth_failed');return false;}
    return true;
}
function nx2_admin(): void {
    static $done=false;
    if($done || ($_GET['plugin_page']??'')!=='nexa-2fa' || !is_user_logged_in()) return;
    $done=true;$ctx=nx2_ctx();$notice='';
    echo '<div class="container-fluid"><h1>Two-factor authentication</h1>';
    $testingHandled=false;
    try{$testingHandled=nx2_testing_screen($ctx);}catch(Throwable $e){echo '<p class="alert alert-danger">'.esc_html($e instanceof RuntimeException?$e->getMessage():'Testing-mode operation failed.').'</p>';}
    $compatHandled=false;
    try{$compatHandled=nx2_compat_screen($ctx);}catch(Throwable $e){echo '<p class="alert alert-danger">Permission-compatibility operation failed. No safety check was silently ignored.</p>';}
    $hostingHandled=false;
    try{$hostingHandled=nx2_hosting_screen($ctx);}catch(Throwable $e){echo '<p class="alert alert-warning">Hosting diagnostics could not complete. Existing key files were not replaced.</p>';}
    $ready=nx2_ready();
    if($ready!=='') {echo '<div class="alert alert-warning">'.esc_html($ready).'</div>';nx2_setup_screen($ctx);echo '</div>';return;}
    echo '<p>Hosting mode: <strong>'.esc_html(nx2_mode()).'</strong>. '.(nx2_mode()==='local'?'Keep a private backup of content/nexa-2fa-private/config.php. Do not delete the private folder or its .htaccess.':(nx2_mode()==='external'?'An existing configuration outside the website supplies the original key. Keep a secure backup.':'Server environment variables supply the key and private lock directory.')).'</p>';
    try {
        if(($_SERVER['REQUEST_METHOD']??'')==='POST' && !isset($_POST['nx2_setup_action']) && !$testingHandled && !$hostingHandled && !$compatHandled) {
            if(!nexa_verify_csrf(is_string($_POST['nx2_csrf']??null)?$_POST['nx2_csrf']:'')) throw new RuntimeException('Security check failed. Reload the page.');
            $notice=nx2_lock(function()use($ctx){
                [$row,$s]=nx2_row($ctx);
                $password=is_string($_POST['nx2_password']??null)?$_POST['nx2_password']:'';
                $code=is_string($_POST['nx2_current_code']??null)?trim($_POST['nx2_current_code']):'';
                if(!nx2_reauth($ctx,$row,$s,$password,$code)) throw new RuntimeException('Password or second factor is invalid. Email-factor users must use a recovery code for management actions.');
                // Re-read after reauth so replay-protection state is never overwritten.
                [$row,$s]=nx2_row($ctx);
                $action=$_POST['nx2_action']??'';
                if($action==='device_preferences') {
                    $days=filter_var($_POST['nx2_preferred_days']??null,FILTER_VALIDATE_INT);
                    if($days===false || $days<1 || $days>90) throw new RuntimeException('Choose a device-trust duration from 1 to 90 days.');
                    $s['trusted_days']=$days;nx2_save($ctx,$row,$s);nx2_audit($ctx,'device_preferences_changed');
                    return 'Your default trusted-device duration was saved. Existing token expirations are unchanged.';
                }
                if($action==='revoke_devices') {
                    $s['devices']=[];nx2_save($ctx,$row,$s);nx2_audit($ctx,'trusted_devices_revoked');
                    return 'All trusted devices were revoked. Stale browser cookies no longer bypass 2FA. Sessions already verified with a factor retain their normal assurance.';
                }
                if($action==='policy') {
                    if(!in_array($ctx['role'],['admin','super_admin'],true) || $ctx['realm']!=='main' || !empty($GLOBALS['nexa_in_site_admin']) || !empty($_SESSION['nexa_admin_site_id'])) throw new RuntimeException('Policy changes are restricted to main-site administrators.');
                    $scope=$_POST['nx2_scope']??'';
                    if(!in_array($scope,['optional','admins','all'],true)) throw new RuntimeException('Invalid policy.');
                    $methods=[];foreach(['totp','email'] as $m) if(isset($_POST['nx2_method_'.$m])) $methods[]=$m;
                    if(!$methods) throw new RuntimeException('Select at least one enrollment method.');
                    if(in_array('email',$methods,true)) {
                        if(!function_exists('nexa_brevo_record_send')) throw new RuntimeException('Enable the Nexa Brevo Email plugin first.');
                        $b=nexa_brevo_settings();
                        if($b['enabled']!=='1' || !in_array('system',(array)$b['categories'],true)) throw new RuntimeException('Enable Brevo live sending and its System category first.');
                    }
                    $old=nx2_policy();
                    $p=['scope'=>$scope,'methods'=>$methods,'version'=>bin2hex(random_bytes(12)),'armed'=>!empty($old['armed']) || $scope!=='optional','trusted_devices'=>isset($_POST['nx2_allow_devices'])];
                    nx2_store_policy($p);
                    if($p['armed']) nx2_arm();
                    nx2_audit($ctx,'policy_changed');
                    return 'Policy saved. Required enrollment and stale-session checks apply on the next protected request.';
                }
                if($action==='enable') {
                    $s['requested']=true;$s['epoch']=bin2hex(random_bytes(12));
                    nx2_save($ctx,$row,$s);nx2_arm();
                    $p=nx2_policy();$p['armed']=true;
                    nx2_store_policy($p);
                    nx2_audit($ctx,'enrollment_requested');
                    return 'Enrollment requested. Open the Dashboard to complete setup through the core challenge screen.';
                }
                if($action==='reset') {
                    $s['factor']='';$s['secret']='';$s['email']='';$s['recovery']=[];$s['last_step']=-1;
                    // Remain opted in: force re-enrollment instead of opening a password-only window.
                    $s['requested']=true;$s['epoch']=bin2hex(random_bytes(12));
                    nx2_save($ctx,$row,$s);nx2_audit($ctx,'factor_reset');unset($_SESSION['nx2_proof'],$_SESSION['nx2_new_recovery']);
                    return 'Factor reset. Open the Dashboard to enroll a replacement. Existing recovery codes are invalid.';
                }
                if($action==='disable') {
                    $p=nx2_policy();$copy=$s;$copy['requested']=false;$copy['factor']='';
                    if(nx2_required($ctx,$copy,$p)) throw new RuntimeException('Site policy requires your account to use 2FA.');
                    $s['requested']=false;$s['factor']='';$s['secret']='';$s['email']='';$s['recovery']=[];$s['last_step']=-1;$s['epoch']=bin2hex(random_bytes(12));
                    nx2_save($ctx,$row,$s);nx2_audit($ctx,'factor_disabled');unset($_SESSION['nx2_proof'],$_SESSION['nx2_new_recovery']);
                    return 'Optional 2FA disabled for this account.';
                }
                throw new RuntimeException('Unknown action.');
            });
        }
        $s=nx2_read($ctx);$p=nx2_policy();
        if (!empty($p['armed'])) nx2_arm();
        if($notice!=='') echo '<div class="alert alert-info">'.esc_html($notice).'</div>';
        echo '<p>Your account: '.esc_html($ctx['username']).' | realm: '.esc_html($ctx['realm']).' | factor: <strong>'.esc_html($s['factor']?:'not enrolled').'</strong> | recovery codes remaining: '.count($s['recovery']).'</p>';
        $recovery=$_SESSION['nx2_new_recovery']??[];
        if(($recovery['identity']??'')===nx2_identity($ctx)) {
            echo '<div class="alert alert-warning"><strong>Save these one-use recovery codes now.</strong> They are shown once. Store them offline, separate from your password.<pre>'.esc_html(implode("\n",$recovery['codes'])).'</pre></div>';
            unset($_SESSION['nx2_new_recovery']);
        }
        echo '<p>Policy: '.esc_html($p['scope']).'. Allowed methods apply to new enrollments; existing factors keep working until reset. Use an authenticator for stronger protection than email. Neither method is phishing-resistant.</p>';
        echo '<h2>Manage your factor</h2><form method="post">';nx2_fields();
        echo '<p><button class="btn btn-primary" name="nx2_action" value="enable">Enable / enroll</button> <button class="btn btn-warning" name="nx2_action" value="reset">Reset and re-enroll</button> <button class="btn btn-default" name="nx2_action" value="disable">Disable optional 2FA</button></p></form>';
        echo '<h2>Trusted devices</h2><p>Trust is granted only after successful 2FA. It still requires normal CMS login and only skips this provider. Cookies are Secure, HttpOnly, SameSite=Lax, bound to your account, factor epoch, policy version and password hash. Maximum 10 records; 1–90 days; initial default 30 days.</p><form method="post">';nx2_fields();
        echo '<label>Your default duration (days) <input type="number" name="nx2_preferred_days" min="1" max="90" value="'.(int)($s['trusted_days']??30).'"></label> <button class="btn btn-primary" name="nx2_action" value="device_preferences">Save my device preference</button> <button class="btn btn-warning" name="nx2_action" value="revoke_devices">Revoke all my trusted devices</button></form><p>Unexpired device records: '.count(array_filter((array)$s['devices'],fn($d)=>(int)$d['expires']>time())).'. Clear this site’s cookies to forget this browser; revoke all to invalidate any copied tokens too.</p>';
        if(in_array($ctx['role'],['admin','super_admin'],true) && $ctx['realm']==='main' && empty($GLOBALS['nexa_in_site_admin']) && empty($_SESSION['nexa_admin_site_id'])) {
            echo '<hr><h2>Site policy</h2><p>Start with Optional, enroll and save recovery codes, test a fresh login, then enforce. Ensure every required account has access to an allowed enrollment method.</p><form method="post">';nx2_fields();
            echo '<label>Enforcement <select name="nx2_scope" class="form-control">';
            foreach(['optional'=>'Optional per user','admins'=>'Administrators required','all'=>'All users required'] as $v=>$label) echo '<option value="'.$v.'"'.($p['scope']===$v?' selected':'').'>'.$label.'</option>';
            echo '</select></label><p>New enrollment methods: ';
            foreach(['totp'=>'Authenticator app','email'=>'Email through Brevo'] as $v=>$label) echo '<label><input type="checkbox" name="nx2_method_'.$v.'"'.(in_array($v,$p['methods'],true)?' checked':'').'> '.$label.'</label> ';
            echo '</p><label><input type="checkbox" name="nx2_allow_devices"'.(!empty($p['trusted_devices'])?' checked':'').'> Allow user-selected trusted devices</label><p>Users choose 1–90 days; initial default 30 days. Policy changes invalidate previous tokens.</p><button class="btn btn-primary" name="nx2_action" value="policy">Save policy</button></form>';
            echo '<hr><h2>Recent audit events</h2><p>Account identities and UTC timestamps. No OTPs, secrets or recovery codes are logged. Automatic retention: 90 days, cleaned on new events.</p><div class="table-responsive"><table class="table"><tr><th>UTC</th><th>Account / realm</th><th>Event</th></tr>';
            $rows=nx2_lock(function(){nx2_ensure();return query('SELECT * FROM nx2_audit ORDER BY id DESC LIMIT 100');});
            foreach($rows as $r) echo '<tr><td>'.esc_html($r['created_at']).'</td><td>'.esc_html($r['username'].' #'.$r['user_id'].' / '.$r['realm']).'</td><td>'.esc_html($r['event']).'</td></tr>';
            echo '</table></div>';
        }
    } catch(Throwable $e) {echo '<div class="alert alert-danger">'.esc_html($e instanceof RuntimeException?$e->getMessage():'2FA operation failed. Check server configuration and storage.').'</div>';}
    echo '</div>';
}
function nx2_fields(): void {
    echo nexa_csrf_field();
    echo '<input type="hidden" name="nx2_csrf" value="'.esc_attr(nexa_csrf_token()).'"><div class="form-group"><label>Current password <input class="form-control" type="password" name="nx2_password" autocomplete="current-password" required></label></div><div class="form-group"><label>Current authenticator code or recovery code (required if already enrolled)<input class="form-control" name="nx2_current_code" autocomplete="one-time-code" maxlength="40"></label></div><p>Email-factor users: use a recovery code to authorize management changes.</p>';
}

add_action('nexa_footer', function(){
    if (!empty($GLOBALS['adminarea']) && !empty($_SESSION['nx2_new_recovery']) && ($_GET['plugin_page'] ?? '')!=='nexa-2fa' && is_user_logged_in()) {
        echo '<div class="alert alert-warning">Your new 2FA recovery codes are ready. <a href="admin.php?plugin_page=nexa-2fa">Open Two-factor authentication now to save them</a>.</div>';
    }
});

add_action('nexa_footer', function(){
    if(!empty($GLOBALS['adminarea']) && is_user_logged_in() && nx2_testing_active()) echo '<div class="alert alert-danger"><strong>2FA TESTING PAUSE ACTIVE — this plugin is not protecting sign-ins.</strong> <a href="admin.php?plugin_page=nexa-2fa">Review / resume policy</a></div>';
});

add_action('nexa_footer', function(){
    if(!empty($GLOBALS['adminarea'])&&is_user_logged_in()&&nx2_permission_exception_active())echo '<div class="alert alert-danger"><strong>2FA PERMISSION OVERRIDE ACTIVE — strict file-permission assurance is NOT satisfied.</strong> <a href="admin.php?plugin_page=nexa-2fa">Review compatibility risk</a></div>';
});
