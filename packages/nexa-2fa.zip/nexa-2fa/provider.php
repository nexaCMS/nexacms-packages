<?php
function nx2_decide(array $ctx): array {
    if(nx2_testing_active()) return ['action'=>'allow'];
    $p=nx2_policy();
    // Configuration problems never silently downgrade a mandatory policy.
    $error=nx2_ready();
    if($error!=='') return $p['scope']==='optional' && empty($p['armed']) ? ['action'=>'allow'] : ['action'=>'deny','message'=>'2FA server configuration is unavailable. Contact the owner.'];
    $s=nx2_read($ctx);
    if(!nx2_required($ctx,$s,$p)) return ['action'=>'allow'];
    if($s['factor'] && nx2_trusted_device($ctx)) {nx2_lock(fn()=>nx2_audit($ctx,'trusted_device_used'));return ['action'=>'allow'];}
    return ['action'=>'challenge','mode'=>$s['factor'] ? 'verify' : 'enroll'];
}
function nx2_session_check(array $ctx,?array $assurance): bool {
    if(nx2_testing_active()) return true;
    $p=nx2_policy();
    if(nx2_ready()!=='') return $p['scope']==='optional' && empty($p['armed']) && !in_array('nexa-2fa',nexa_auth_required_providers(),true);
    $s=nx2_read($ctx);
    if(!nx2_required($ctx,$s,$p)) return true;
    if($s['factor'] && nx2_trusted_device($ctx)) return true;
    $proof=$_SESSION['nx2_proof'] ?? [];
    return !empty($s['factor']) && in_array('nexa-2fa',(array)($assurance['providers'] ?? []),true)
        && ($proof['identity'] ?? '')===nx2_identity($ctx) && ($proof['version'] ?? '')===$p['version']
        && ($proof['epoch'] ?? '')===$s['epoch'];
}
function nx2_session_data(array $ctx,array $pending): array {
    $id=(string)$pending['id'];
    $d=$_SESSION['nx2_challenge'] ?? [];
    if(($d['id'] ?? '')!==$id || ($d['identity'] ?? '')!==nx2_identity($ctx)) {
        $p=nx2_policy();
        $d=['id'=>$id,'identity'=>nx2_identity($ctx),'method'=>$p['methods'][0] ?? 'totp',
            'secret'=>nx2_seal(['secret'=>nx2_b32(random_bytes(20))]),'email_hash'=>'','email_expires'=>0,'last_send'=>0];
        $_SESSION['nx2_challenge']=$d;
    }
    return $d;
}
function nx2_render(array $ctx,array $pending): void {
    try {
        $s=nx2_read($ctx);$d=nx2_session_data($ctx,$pending);$p=nx2_policy();
        $enroll=empty($s['factor']);$method=$enroll ? $d['method'] : $s['factor'];
        echo '<p>'.($enroll ? 'Set up your second factor to continue.' : 'Verify your second factor to continue.').'</p>';
        if($enroll) {
            echo '<label>Enrollment method <select name="nx2_method" class="form-control">';
            foreach($p['methods'] as $m) echo '<option value="'.esc_attr($m).'"'.($d['method']===$m?' selected':'').'>'.($m==='totp'?'Authenticator app':'Email through Brevo').'</option>';
            echo '</select></label><button class="btn btn-default" name="nx2_action" value="method" formnovalidate>Choose method</button>';
        }
        if($method==='totp' && $enroll) {
            $secret=nx2_open($d['secret'])['secret'];
            echo '<p>In your authenticator app choose <strong>Add account → Enter setup key</strong>. Use time-based codes, SHA-1, 6 digits, 30 seconds.</p><p>Account: '.esc_html($ctx['username']).' ('.esc_html($ctx['realm']).')</p><p>Secret: <code>'.esc_html($secret).'</code></p><p>Save recovery codes from the 2FA screen after signing in. Never share this secret.</p>';
        } elseif($method==='email') {
            echo '<p>A code is sent only to the email address already stored on your CMS account. Codes expire in 5 minutes. Resend invalidates the previous code.</p><button class="btn btn-default" name="nx2_action" value="email" formnovalidate>Send / resend email code</button>';
        }
        nx2_trust_fields($s,$p);
        echo '<div class="form-group"><label>Code'.(!$enroll?' (or one-use recovery code)':'').'<input class="form-control" name="nx2_code" autocomplete="one-time-code" maxlength="40" required></label></div><button class="btn btn-primary btn-block" name="nx2_action" value="verify">'.($enroll?'Confirm enrollment':'Verify').'</button>';
    } catch(Throwable $e) { echo '<p class="alert alert-danger">2FA is unavailable. Contact the owner and check deployment configuration.</p>'; }
}
function nx2_verify(array $ctx,array $pending,array $post): array {
    if(nx2_testing_active()) return ['ok'=>false,'error'=>'2FA is paused for testing. Cancel this challenge and sign in again using normal CMS authentication.'];
    return nx2_lock(function()use($ctx,$pending,$post){
        [$row,$s]=nx2_row($ctx);$p=nx2_policy();$d=nx2_session_data($ctx,$pending);
        $account=nx2_account($ctx);$enroll=empty($s['factor']);
        $action=is_string($post['nx2_action'] ?? null)?$post['nx2_action']:'verify';
        if($enroll && $action==='method') {
            $m=$post['nx2_method'] ?? '';
            if(!is_string($m) || !in_array($m,$p['methods'],true)) return ['ok'=>false,'error'=>'Choose an allowed enrollment method.'];
            $d['method']=$m;$d['email_hash']='';$_SESSION['nx2_challenge']=$d;
            return ['ok'=>false,'error'=>'Method selected. Follow the instructions below.'];
        }
        $method=$enroll?$d['method']:$s['factor'];
        if($enroll && !in_array($method,$p['methods'],true)) return ['ok'=>false,'error'=>'Enrollment policy changed. Choose another method.'];
        $now=time();
        if($now-(int)$s['window']>=900){$s['window']=$now;$s['attempts']=0;}
        if((int)$s['attempts']>=5) return ['ok'=>false,'error'=>'Too many attempts for this account. Wait 15 minutes from the first attempt.'];
        if($action==='email' && $method==='email') {
            if($now-(int)$s['send_window']>=3600){$s['send_window']=$now;$s['sent']=0;}
            if($s['sent']>=5 || $now-(int)$s['last_send']<60) return ['ok'=>false,'error'=>'Email limit reached. Wait at least 60 seconds; maximum 5 sends per hour per account.'];
            $email=(string)($account['email'] ?? '');
            if(!filter_var($email,FILTER_VALIDATE_EMAIL) || preg_match('/[\r\n]/',$email)) return ['ok'=>false,'error'=>'The account needs a valid CMS email address. Contact the administrator.'];
            if(!$enroll && !hash_equals($s['email'],$email)) return ['ok'=>false,'error'=>'The account email changed. Use a recovery code, then reset and re-enroll your factor.'];
            $s['sent']++;$s['last_send']=$now;$s['email_nonce']=bin2hex(random_bytes(16));nx2_save($ctx,$row,$s);
            $code=(string)random_int(100000,999999);
            $d['email_hash']=hash_hmac('sha256',$pending['id']."\0".$email."\0".$code,nx2_key());
            $d['email_nonce']=$s['email_nonce'];$d['email_expires']=$now+300;$d['last_send']=$now;$d['email']=$email;
            $_SESSION['nx2_challenge']=$d;
            // Do not queue login OTPs or bypass the Brevo live/category switches.
            if(!function_exists('nexa_brevo_record_send') || !function_exists('nexa_brevo_settings')) $result=['ok'=>false];
            else {
                $b=nexa_brevo_settings();$b['delivery_mode']='immediate';
                $result=$b['enabled']==='1' && in_array('system',(array)$b['categories'],true)
                    ? nexa_brevo_record_send($b,$email,'Your NexaCMS sign-in code','Your sign-in code is '.$code.'. It expires in 5 minutes. If you did not request this, ignore it.', ['category'=>'system','source'=>'nexa-2fa'])
                    : ['ok'=>false];
            }
            if(empty($result['ok'])) {$_SESSION['nx2_challenge']['email_hash']='';nx2_audit($ctx,'email_send_failed');return ['ok'=>false,'error'=>'Code could not be sent. Check Brevo Email activity, live sending and the System category. No fallback login was granted.'];}
            nx2_audit($ctx,'email_code_sent');
            return ['ok'=>false,'error'=>'Code accepted by the email provider. Check your inbox/spam folder.'];
        }
        $s['attempts']++; // Shared across sessions; resending never resets verification attempts.
        $code=is_string($post['nx2_code'] ?? null)?trim($post['nx2_code']):'';
        $ok=false;$recovery=false;
        if(!$enroll && nx2_recovery_consume($s,$code)) {$ok=true;$recovery=true;}
        elseif($method==='totp') {
            $secret=$enroll?nx2_open($d['secret'])['secret']:$s['secret'];
            $step=nx2_match_totp($secret,$code,(int)$s['last_step'],$now);
            if($step!==null){$ok=true;$s['last_step']=$step;}
        } elseif($method==='email') {
            $email=(string)($account['email'] ?? '');
            $hash=hash_hmac('sha256',$pending['id']."\0".$email."\0".$code,nx2_key());
            $ok=preg_match('/^[0-9]{6}$/D',$code) && $s['email_nonce']!=='' && hash_equals($s['email_nonce'],(string)($d['email_nonce']??'')) && $d['email_hash']!=='' && $d['email_expires']>$now
                && ($enroll || hash_equals($s['email'],$email)) && hash_equals($d['email_hash'],$hash);
        }
        if(!$ok) return nx2_fail($ctx,$row,$s,'Invalid, expired or already-used code.');
        if($enroll) {
            $s['factor']=$method;$s['requested']=true;$s['secret']=$method==='totp'?nx2_open($d['secret'])['secret']:'';
            $s['email']=$method==='email'?(string)$account['email']:'';
            [$codes,$s['recovery']]=nx2_recovery();
            $_SESSION['nx2_new_recovery']=['identity'=>nx2_identity($ctx),'codes'=>$codes];
            $s['epoch']=bin2hex(random_bytes(12));
        }
        $trust=null;
        if(($post['nx2_trust_device']??'')==='yes' && !empty($p['trusted_devices']) && !headers_sent()) {
            $days=filter_var($post['nx2_trust_days']??($s['trusted_days']??30),FILTER_VALIDATE_INT);
            if($days===false || $days<1 || $days>90) $days=(int)($s['trusted_days']??30);
            $trust=nx2_device_material($ctx,$s,$p,$account,$days);
        }
        $s['attempts']=0;$s['email_nonce']='';nx2_save($ctx,$row,$s);nx2_audit($ctx,$enroll?'enrollment_completed':($recovery?'recovery_used':'verification_succeeded'));
        if($trust!==null && nx2_send_trust_cookie($trust)) nx2_audit($ctx,'trusted_device_issued');
        $_SESSION['nx2_proof']=['identity'=>nx2_identity($ctx),'version'=>$p['version'],'epoch'=>$s['epoch']];
        unset($_SESSION['nx2_challenge']);
        return ['ok'=>true];
    });
}
