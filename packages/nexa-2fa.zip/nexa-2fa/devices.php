<?php
function nx2_testing(): array {
    return nx2_network(function(){
        $s=json_decode((string)get_setting('nx2_testing','{}'),true);
        return is_array($s)?$s:[];
    });
}
function nx2_testing_active(): bool { $t=nx2_testing();return !empty($t['enabled']) && (int)($t['expires']??0)>time(); }
function nx2_testing_screen(array $ctx): bool {
    $admin=is_user_logged_in() && in_array($ctx['role'],['admin','super_admin'],true) && $ctx['realm']==='main' && empty($_SESSION['nexa_admin_site_id']) && empty($GLOBALS['nexa_in_site_admin']);
    $handled=false;$notice='';
    if($admin && ($_SERVER['REQUEST_METHOD']??'')==='POST' && isset($_POST['nx2_testing_action'])) {
        $handled=true;
        if(!nexa_verify_csrf(is_string($_POST['nx2_csrf']??null)?$_POST['nx2_csrf']:'')) $notice='Testing-mode security check failed. Reload the page.';
        elseif(!in_array($_POST['nx2_testing_action'],['pause','resume'],true)) $notice='Invalid testing action.';
        elseif($_POST['nx2_testing_action']==='pause' && ($_POST['nx2_testing_ack']??'')!=='yes') $notice='Confirm that this disables this plugin’s second-factor checks for everyone.';
        else {
            // A deliberate, CSRF-protected administration operation, equivalent in
            // authority to disabling a plugin. No factor/key lookup is required.
            $on=$_POST['nx2_testing_action']==='pause';
            $record=['enabled'=>$on,'expires'=>$on?time()+86400:0,'changed_at'=>gmdate('c'),
                'actor_id'=>$ctx['user_id'],'actor'=>$ctx['username'],'reason'=>'explicit administrator testing pause'];
            nx2_network(function()use($record){
                loadsettings();set_setting('nx2_testing',json_encode($record,JSON_THROW_ON_ERROR));
                $r=query('SELECT value FROM settings WHERE setting = ?', ['nx2_testing']);
                if(count($r)!==1 || json_decode((string)$r[0]['value'],true)!==$record) throw new RuntimeException('Testing-mode write could not be confirmed.');
            });
            unset($_SESSION['nx2_proof']);
            $notice=$on?'Testing pause enabled for 24 hours. This plugin’s 2FA is NOT protecting sign-ins.':'Testing pause ended. The configured policy applies on the next protected request.';
        }
    }
    if($notice!=='') echo '<div class="alert alert-warning">'.esc_html($notice).'</div>';
    $t=nx2_testing();
    if(nx2_testing_active()) echo '<div class="alert alert-danger"><strong>UNSECURED TESTING MODE: this plugin’s second-factor checks are paused for everyone.</strong> Normal CMS login and other providers still apply. Expires '.esc_html(gmdate('Y-m-d H:i:s',(int)$t['expires'])).' UTC. Last changed by '.esc_html((string)($t['actor']??'administrator')).'.</div>';
    if($admin) {
        echo '<details><summary><strong>Testing pause / continue without this plugin’s 2FA</strong></summary><p>This does not fix setup, bypass account validation, or make storage secure. It is a deliberate site-wide pause, available to an already authenticated main-site administrator. It expires in 24 hours; resume earlier when ready.</p><form method="post">';echo nexa_csrf_field();
        echo '<input type="hidden" name="nx2_csrf" value="'.esc_attr(nexa_csrf_token()).'">';
        if(nx2_testing_active()) echo '<button class="btn btn-warning" name="nx2_testing_action" value="resume">Resume configured 2FA policy</button>';
        else echo '<label><input type="checkbox" name="nx2_testing_ack" value="yes" required> I understand this pauses this plugin’s 2FA for everyone.</label> <button class="btn btn-warning" name="nx2_testing_action" value="pause">Continue unsecured for testing (24 hours)</button>';
        echo '</form></details><hr>';
    }
    return $handled;
}
function nx2_device_cookie(array $ctx): string { return '__Secure-nx2_'.substr(nx2_identity($ctx),0,20); }
function nx2_password_tag(array $account): string { return hash_hmac('sha256',(string)($account['pass']??''),nx2_key()); }
function nx2_device_material(array $ctx,array &$s,array $p,array $account,int $days): array {
    $days=max(1,min(90,$days));$selector=bin2hex(random_bytes(12));$validator=bin2hex(random_bytes(32));$expires=time()+$days*86400;
    $s['devices']=array_filter((array)($s['devices']??[]),fn($d)=>(int)($d['expires']??0)>time());
    while(count($s['devices'])>=10) array_shift($s['devices']);
    $s['devices'][$selector]=['hash'=>hash('sha256',$validator),'expires'=>$expires,'created'=>time(),
        'identity'=>nx2_identity($ctx),'role'=>(string)($account['role']??$ctx['role']),'version'=>$p['version'],'epoch'=>$s['epoch'],'password_tag'=>nx2_password_tag($account)];
    return ['name'=>nx2_device_cookie($ctx),'value'=>$selector.'.'.$validator,'expires'=>$expires];
}
function nx2_device_matches(array $ctx,array $s,array $p,array $account,string $cookie): bool {
    if(empty($p['trusted_devices']) || empty($s['factor']) || !preg_match('/^([a-f0-9]{24})\.([a-f0-9]{64})$/D',$cookie,$m)) return false;
    $d=$s['devices'][$m[1]]??null;
    return is_array($d) && ($d['identity']??'')===nx2_identity($ctx) && ($d['role']??'')===(string)($account['role']??$ctx['role']) && (int)$d['expires']>time() && ($d['version']??'')===$p['version']
        && ($d['epoch']??'')===$s['epoch'] && hash_equals((string)($d['password_tag']??''),nx2_password_tag($account))
        && hash_equals((string)($d['hash']??''),hash('sha256',$m[2]));
}
function nx2_trusted_device(array $ctx): bool {
    $cookie=$_COOKIE[nx2_device_cookie($ctx)]??'';
    if(!is_string($cookie) || $cookie==='') return false;
    return nx2_lock(function()use($ctx,$cookie){
        [, $s]=nx2_row($ctx);$p=nx2_policy();$account=nx2_account($ctx);
        return nx2_device_matches($ctx,$s,$p,$account,$cookie);
    });
}
function nx2_send_trust_cookie(array $cookie): bool {
    if(headers_sent()) return false;
    return setcookie($cookie['name'],$cookie['value'],['expires'=>$cookie['expires'],'path'=>'/',
        'secure'=>true,'httponly'=>true,'samesite'=>'Lax']);
}
function nx2_trust_fields(array $s,array $p): void {
    if(empty($p['trusted_devices'])) return;
    $days=max(1,min(90,(int)($s['trusted_days']??30)));
    echo '<p><label><input type="checkbox" name="nx2_trust_device" value="yes"> Trust this device after successful verification</label> for <input type="number" name="nx2_trust_days" value="'.$days.'" min="1" max="90" style="width:75px"> days.</p><p>Default comes from your account settings (30 days initially). Use only on a private device over HTTPS. This skips this provider’s repeat 2FA, not your password or other providers. You can revoke trusted devices later.</p>';
}
