<?php
/** Explicit local permission-metadata exception, not a general force-authentication flag. */
function nx2_permission_record(): array {
    return nx2_network(function(){ $r=json_decode((string)get_setting('nx2_permission_exception','{}'),true);return is_array($r)?$r:[]; });
}
function nx2_compat_admin(array $ctx): void {
    if(!is_user_logged_in()||!in_array($ctx['role'],['admin','super_admin'],true)||$ctx['realm']!=='main'||!empty($_SESSION['nexa_admin_site_id'])||!empty($GLOBALS['nexa_in_site_admin']))throw new RuntimeException('Permission compatibility controls require a main-site administrator.');
}
function nx2_compat_binding(): string {
    $dir=@realpath(nx2_local_dir());
    if(!$dir)throw new RuntimeException('Local private directory is unavailable.');
    $source=@file_get_contents($dir.'/config.php');$rules=@file_get_contents($dir.'/.htaccess');
    if($source===false||$rules===false)throw new RuntimeException('Local configuration/protection cannot be read.');
    return hash('sha256',$dir."\0".nx2_normalize_rules($source)."\0".nx2_normalize_rules($rules));
}
function nx2_permission_exception_active(): bool {
    if(nx2_mode()!=='local')return false;
    $r=nx2_permission_record();if(empty($r['enabled']))return false;
    try{return hash_equals((string)($r['binding']??''),nx2_compat_binding());}catch(Throwable $e){return false;}
}
function nx2_readiness_label(): string {
    $error=nx2_ready();if($error!=='')return $error;
    return nx2_permission_exception_active()?'USABLE WITH EXPLICIT PERMISSION OVERRIDE — strict permission checks are NOT satisfied':'passed';
}
function nx2_compat_preflight(): array {
    if(nx2_mode()!=='local')throw new RuntimeException('This exception applies only to protected LOCAL mode, not environment/external configuration.');
    if(!function_exists('nexa_auth_decide_all')||!function_exists('nexa_auth_enforce_session_assurance'))throw new RuntimeException('NexaCMS 1.29.1+ is required and cannot be overridden.');
    if(!extension_loaded('sodium')||!function_exists('flock'))throw new RuntimeException('Sodium and file locking are required and cannot be overridden.');
    $c=nx2_configuration();$key=base64_decode((string)($c['key']??''),true);
    if($key===false||strlen($key)!==32)throw new RuntimeException('A valid ORIGINAL encryption key is required; none will be generated.');
    $local=@realpath(nx2_local_dir());$locks=@realpath((string)$c['lock_dir']);
    if(!$local||!$locks||$locks!==$local.'/locks'||!is_writable($locks))throw new RuntimeException('The original local locks directory must be available and writable.');
    if(($c['protection']??'')!=='browser-probe-v1'||nx2_normalize_rules((string)@file_get_contents($local.'/.htaccess'))!==nx2_normalize_rules(nx2_deny_rules()))throw new RuntimeException('Required .htaccess protection is missing/changed. This cannot be overridden.');
    $nonce=random_bytes(24);$plain=random_bytes(32);$sealed=sodium_crypto_secretbox($plain,$nonce,$key);
    if(sodium_crypto_secretbox_open($sealed,$nonce,$key)!==$plain)throw new RuntimeException('Encryption self-test failed.');
    return ['local'=>$local,'locks'=>$locks,'binding'=>nx2_compat_binding()];
}
function nx2_compat_save(array $record): void {
    nx2_network(function()use($record){loadsettings();$value=json_encode($record,JSON_THROW_ON_ERROR);set_setting('nx2_permission_exception',$value);
        $r=query('SELECT value FROM settings WHERE setting = ?', ['nx2_permission_exception']);
        if(count($r)!==1||(string)$r[0]['value']!==$value)throw new RuntimeException('Permission-exception setting write could not be confirmed.');
    });
}
function nx2_compat_cleanup(): void {
    $p=$_SESSION['nx2_compat_pending']??[];
    if(!empty($p['name'])&&is_string($p['name'])&&preg_match('/^compat-[a-f0-9]{24}\.txt$/D',$p['name'])){
        foreach([nx2_local_dir().'/'.$p['name'],dirname(nx2_local_dir()).'/nx2-'.$p['name']] as $path)if(is_file($path))@unlink($path);
    }
    unset($_SESSION['nx2_compat_pending']);
}
function nx2_compat_prepare(array $ctx,string $password,string $code,bool $ack): void {
    nx2_compat_admin($ctx);if(!$ack)throw new RuntimeException('Explicitly accept the permission/isolation risk first.');
    if(!nx2_testing_active())throw new RuntimeException('Enable the 24-hour testing pause before preparing a permission exception.');
    $c=nx2_compat_preflight();
    $test=nx2_probe_directory($c['locks']);
    if(($test['Temporary write/read']??'')!=='passed'||($test['Lock contention']??'')!=='passed: competing handle was refused'||($test['Temporary cleanup']??'')!=='passed')throw new RuntimeException('Actual write/read, cleanup or lock-contention test failed. This cannot be overridden.');
    $h=@fopen($c['locks'].'/nexa-2fa.lock','c');if(!$h)throw new RuntimeException('Cannot open the actual account lock.');
    try{
        if(!flock($h,LOCK_EX|LOCK_NB))throw new RuntimeException('A sign-in operation is active; retry later.');
        nx2_network(function()use($ctx,$password,$code){
            [$row,$s]=nx2_row($ctx);
            if(!nx2_reauth($ctx,$row,$s,$password,$code))throw new RuntimeException('Current password or existing second factor/recovery code is invalid. No identity/factor check was bypassed.');
        });
    }finally{@flock($h,LOCK_UN);fclose($h);}
    nx2_compat_cleanup();$name='compat-'.bin2hex(random_bytes(12)).'.txt';$token=bin2hex(random_bytes(24));$created=[];
    try{
        foreach([dirname(nx2_local_dir()).'/nx2-'.$name,nx2_local_dir().'/'.$name] as $path){$f=@fopen($path,'x');if(!$f)throw new RuntimeException('Cannot exclusively create browser probe.');$created[]=$path;$n=fwrite($f,$token);fclose($f);if($n!==strlen($token))throw new RuntimeException('Cannot write browser probe.');}
        @chmod($created[0],0644); // Harmless public marker, no key data.
    }catch(Throwable $e){foreach($created as $path)@unlink($path);throw $e;}
    $_SESSION['nx2_compat_pending']=['name'=>$name,'token'=>$token,'binding'=>$c['binding'],'identity'=>nx2_identity($ctx),'expires'=>time()+600,'ack'=>true];
}
function nx2_compat_finish(array $ctx,array $post): void {
    nx2_compat_admin($ctx);$c=nx2_compat_preflight();$p=$_SESSION['nx2_compat_pending']??[];
    if(empty($p['ack'])||($p['identity']??'')!==nx2_identity($ctx)||(int)($p['expires']??0)<time()||($p['binding']??'')!==$c['binding'])throw new RuntimeException('Permission approval expired or its account/files changed. Prepare again.');
    if(!nx2_testing_active())throw new RuntimeException('The testing pause must remain active during approval.');
    $token=is_string($post['nx2_compat_token']??null)?$post['nx2_compat_token']:'';
    if(!hash_equals($p['token'],$token)||($post['nx2_compat_public']??'')!=='yes'||!in_array((string)($post['nx2_compat_status']??''),['403','404'],true))throw new RuntimeException('Fresh browser protection test did not pass. Permission override refused.');
    nx2_compat_save(['enabled'=>true,'binding'=>$c['binding'],'actor'=>$ctx['username'],'actor_id'=>$ctx['user_id'],'accepted_at'=>gmdate('c'),'reason'=>'Administrator explicitly accepts reported permission-bit/isolation risk after fresh browser protection test']);
    nx2_compat_cleanup();
}
function nx2_compat_screen(array $ctx): bool {
    try{nx2_compat_admin($ctx);}catch(Throwable $e){return false;}
    $handled=false;$notice='';
    if(($_SERVER['REQUEST_METHOD']??'')==='POST'&&isset($_POST['nx2_compat_action'])){
        $handled=true;
        try{
            if(!nexa_verify_csrf(is_string($_POST['nx2_csrf']??null)?$_POST['nx2_csrf']:''))throw new RuntimeException('Compatibility-control security check failed.');
            $action=$_POST['nx2_compat_action'];
            if($action==='prepare')nx2_compat_prepare($ctx,is_string($_POST['nx2_compat_password']??null)?$_POST['nx2_compat_password']:'',is_string($_POST['nx2_compat_code']??null)?trim($_POST['nx2_compat_code']):'',($_POST['nx2_compat_ack']??'')==='yes');
            elseif($action==='finish'){nx2_compat_finish($ctx,$_POST);$notice='Permission compatibility exception enabled. The key was preserved. Resume the testing pause before testing real enrollment. Strict file-permission assurance is NOT satisfied.';}
            elseif($action==='revoke'){
                if(!nx2_testing_active())throw new RuntimeException('Enable testing pause first: restoring strict checks may block enrolled users on this host.');
                nx2_compat_save(['enabled'=>false,'actor'=>$ctx['username'],'actor_id'=>$ctx['user_id'],'revoked_at'=>gmdate('c')]);nx2_compat_cleanup();$notice='Permission exception revoked. Strict checks apply again; the testing pause remains active.';
            }else throw new RuntimeException('Unknown compatibility action.');
        }catch(Throwable $e){$notice=$e instanceof RuntimeException?$e->getMessage():'Permission-exception operation failed. No safety check was silently ignored.';}
    }
    if($notice!=='')echo '<p class="alert alert-warning">'.esc_html($notice).'</p>';
    if(nx2_permission_exception_active()){
        $r=nx2_permission_record();echo '<div class="alert alert-danger"><strong>PERMISSION OVERRIDE ACTIVE — NOT STRICTLY SECURED.</strong> Local permission bits are explicitly ignored; browser-denial checks do not prove filesystem/co-tenant isolation. Accepted by '.esc_html((string)($r['actor']??'administrator')).' on '.esc_html((string)($r['accepted_at']??'')).'. Keep secure backups and move to stricter hosting when possible.</div>';
    }
    echo '<details'.($handled?' open':'').'><summary><strong>Force enable — permission compatibility only (experimental)</strong></summary><p>This is an explicit risk exception for hosts reporting fixed/unchangeable 0666 modes. It does NOT make those files private. It can ignore only the local file/folder permission-bit checks, after a new browser protection test. Missing keys, sodium, locks, identity validation or .htaccess protection CANNOT be overridden. Other local processes able to read/change your files may still compromise all factors. Keep this off when strict setup is possible.</p>';
    if(nx2_mode()!=='local'){echo '<p>Available only for an existing protected local configuration. No key will be generated or replaced.</p></details><hr>';return $handled;}
    echo '<p>First enable the explicit testing pause. Confirm your current password (plus authenticator/recovery code if already enrolled), accept the risk and prepare the browser test. After approval, end the pause and enroll normally. This approval has no automatic expiry to avoid unexpected lockouts; revoke it deliberately or migrate to stricter hosting.</p>';
    $p=$_SESSION['nx2_compat_pending']??[];
    if(!empty($p)&&($p['identity']??'')===nx2_identity($ctx)&&(int)$p['expires']>=time()){
        echo '<button type="button" class="btn btn-warning" id="nx2-compat-probe">Verify protection and accept permission override</button><p id="nx2-compat-result" role="status"></p><form method="post" id="nx2-compat-finish" style="display:none">';echo nexa_csrf_field();
        echo '<input name="nx2_csrf" value="'.esc_attr(nexa_csrf_token()).'"><input name="nx2_compat_action" value="finish"><input name="nx2_compat_token" value="'.esc_attr($p['token']).'"><input name="nx2_compat_public" value="yes"><input name="nx2_compat_status" id="nx2-compat-status"></form>';
        $base=rtrim((string)(parse_url(baseurl(),PHP_URL_PATH)?:''),'/');$data=json_encode(['public'=>$base.'/content/nx2-'.$p['name'],'private'=>$base.'/content/nexa-2fa-private/'.$p['name'],'token'=>$p['token']],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
        echo '<script>(function(){const p='.$data.',b=document.getElementById("nx2-compat-probe"),o=document.getElementById("nx2-compat-result");b.onclick=async()=>{b.disabled=true;try{const opts={cache:"no-store",credentials:"same-origin",redirect:"error"};const a=await fetch(p.public,opts);if(a.status!==200||(await a.text()).trim()!==p.token)throw new Error("Public control could not be verified.");const r=await fetch(p.private,opts),body=await r.text();if(![403,404].includes(r.status)||body.includes(p.token))throw new Error("Private-folder denial failed (HTTP "+r.status+").");document.getElementById("nx2-compat-status").value=String(r.status);document.getElementById("nx2-compat-finish").submit();}catch(e){o.textContent=e.message+" No exception was granted. Redirects, bot checks and network errors do not count as protection.";b.disabled=false;}};})();</script>';
    }else{
        echo '<form method="post">';echo nexa_csrf_field();
        echo '<input type="hidden" name="nx2_csrf" value="'.esc_attr(nexa_csrf_token()).'"><label>Current password <input class="form-control" type="password" name="nx2_compat_password" autocomplete="current-password" required></label><label>Authenticator/recovery code (only if enrolled) <input class="form-control" name="nx2_compat_code" autocomplete="one-time-code" maxlength="40"></label><p><label><input type="checkbox" name="nx2_compat_ack" value="yes" required> I accept that reported writable permissions/co-tenant access remain unverified, despite a browser-denied folder. I want experimental compatibility rather than strict readiness.</label></p><button class="btn btn-warning" name="nx2_compat_action" value="prepare">Prepare permission-only force enable</button></form>';
    }
    if(!empty(nx2_permission_record()['enabled'])){echo '<form method="post">';echo nexa_csrf_field();echo '<input type="hidden" name="nx2_csrf" value="'.esc_attr(nexa_csrf_token()).'"><button class="btn btn-default" name="nx2_compat_action" value="revoke">Revoke exception / restore strict permissions (pause required)</button></form>';}
    echo '</details><hr>';return $handled;
}
