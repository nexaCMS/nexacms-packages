# Nexa 2FA v0.5.0 — choose either hosting mode

Requires NexaCMS **1.29.1+**, PHP sodium and reliable file locking. No CMS core changes are included. Use staging and keep hosting access while testing.

## Update from an earlier version

Back up your current plugin folder and database, then replace **only** `content/plugins/nexa-2fa/` with the new ZIP's `nexa-2fa/` folder. Use the CMS uploader if it supports replacement, otherwise File Manager. Leave the Pre stage enabled.

**Do not delete existing keys, environment settings or private data folders.** This update does not need to reset enrolled factors.

## New: force-enable only the permission compatibility exception

For your current LOCAL config with reported 0666 modes, you can now explicitly accept the risk rather than satisfy those permission-bit checks. This is **experimental and not strict security**. It does not fix permissions or prove isolation from other processes on the host.

1. Enable the **24-hour testing pause** at the top of the plugin screen.
2. Expand **Force enable — permission compatibility only (experimental)**.
3. Enter your current CMS password (and authenticator/recovery code if already enrolled), check the risk acknowledgement, and click **Prepare permission-only force enable**.
4. Click **Verify protection and accept permission override**. The browser must verify the public marker and a genuinely denied private marker; failures cannot be ignored.
5. After success, **end the testing pause**, leave enforcement Optional, then Enable/enroll your real second factor. Save recovery codes and test a fresh login first.

This retains the original key. It waives only LOCAL file/folder permission-bit checks. It cannot waive a missing key, sodium, write/read/locking failure, account mismatch or missing web protection. HTTP 200/500, redirects and bot-check failures do not count as private-folder protection. Outside-folder access restrictions remain unchanged.

The accepted exception remains until revoked or its config/path/protection binding changes. Warnings say **PERMISSION OVERRIDE ACTIVE — NOT STRICTLY SECURED**. Revoke it after enabling the testing pause if you want to restore strict checks. This exception is separate from the testing pause: ending the pause restores REAL 2FA while retaining the acknowledged permission risk.

## If FileZilla reports CHMOD 550 / files stay 0666

Do not keep repeating CHMOD or regenerate your key.

1. Open the new **Hosting diagnostics / external private-file mode** panel on the plugin screen. It is available even when setup is blocked.
2. For the current file reports, paste the **absolute local directory shown in the panel** into the path box and click **Run harmless directory tests**. This shows permissions as PHP sees them. The external-mode location check is expected to fail for an in-htdocs directory; other results remain useful.
3. For your copy outside htdocs, test the suggested parent-directory candidate. It is derived from the actual PHP CMS path, not a guaranteed FTP mapping. If it cannot be resolved, ask the host for the PHP filesystem path/access policy; do not guess paths repeatedly.
4. Diagnostics use only randomly named non-secret temporary files. Keys/file contents are not displayed, and existing files are not modified. Share the table/error text, **not config.php**.

### Option C — existing external private-file configuration

If PHP access and all external safety checks pass, you can select the copied ORIGINAL config outside htdocs without environment variables:

1. Back up the original config securely, restrict site access, and enable the explicit 24-hour testing pause.
2. The candidate must contain the existing generated `config.php` (0600) and `locks/` folder; both outside private/locks folders must be 0700. No public URL alias should expose them. The copied file must contain the SAME key.
3. Enter your CMS password and click **Validate and use existing external configuration**.
4. The plugin verifies the key and existing encrypted data, then stores only a keyless path pointer. It does not delete/copy/rewrite private config files or generate a key. Check that active mode becomes **external**.
5. Verify your secure backup, then remove the OLD in-htdocs private folder using File Manager to finish migration. Do not remove the active external folder. Resume policy and test new login/recovery.

Precedence: **environment variables > external pointer > local file**. A missing/broken selected external file does not silently fall back to the old copy.

If PHP cannot access the outside folder, or it also reports fixed 0666 permissions there, activation will refuse. This update does not bypass hosting restrictions or certify unverified storage. Continue explicitly unsecured testing if needed, or ask the host for suitable private storage.

FTP text-transfer CRLF line endings are now accepted for otherwise unchanged generated config/protection files. Config source is parsed, not executed; unexpected PHP/config edits are rejected.

## Option B — easiest for InfinityFree/File Manager hosting

No terminal access or environment variables are needed for this mode.

1. Open **Admin → Two-factor authentication** as the main-site administrator.
2. Under **Option B — shared-hosting / File Manager mode**, enter your current CMS password and click **Prepare shared-hosting setup**.
3. Click **Verify protection and finish setup**.
4. The browser checks a public harmless marker and a protected private marker. Private access must return HTTP **403 or 404** without leaking the marker. Redirects, bot-check pages, HTTP 500 and network failures do not pass. No key is created when the check fails.
5. On success the plugin generates and saves its key, then asks you to reload the page. The active mode should show **local**.
6. Using File Manager, make a private backup of `content/nexa-2fa-private/config.php` somewhere **off the public website**. Keep the folder's `.htaccess` in place; File Manager may hide dotfiles until you enable their display.

Do not share the key/config file in chat, screenshots or public backups. The wizard does not display it. The local PHP config refuses direct execution, and the entire private folder has server deny rules.

**If a check fails:** stop and share the error text only. Hosts that lack sodium, reliable locking, writable storage or server-enforced .htaccess protection cannot use this mode safely. Compatibility has been tested on isolated Apache, not on your live InfinityFree account. There is no bypass button for a failed protection check.

The browser reports the protection result under your authenticated, password-confirmed, CSRF-protected setup session. This is an installation check, not independent server attestation. After changing hosts/domains/server configuration, have your developer recheck harmless public/private markers before reopening the site: runtime checks detect a missing/changed .htaccess file but cannot prove a new server still honors it.

## Option A — environment mode, retained for other hosts

Set these in the environment of the PHP **web process**:

- `NEXA_2FA_KEY`: a base64-encoded random 32-byte key.
- `NEXA_2FA_LOCK_DIR`: an existing private directory outside the CMS and public document root, owned by PHP, permissions **0700**.

To generate a key privately for a NEW installation:

```sh
php -r 'echo base64_encode(random_bytes(32)), PHP_EOL;'
```

If either variable is set, environment mode takes precedence and BOTH must be valid. It will not silently fall back to the local key or mix the two modes. Existing environment-mode installations keep working without using the wizard.

When migrating an enrolled installation, preserve its ORIGINAL key. A different key cannot decrypt the factors. The wizard refuses to generate a replacement key when existing configuration, enrolled/requested account data or an armed policy is found. Follow the full README for migration and recovery.

## Enroll before enforcing

1. Keep enforcement **Optional** initially.
2. Enter your current password and click **Enable / enroll**, then open Dashboard.
3. Follow the core challenge screen. Authenticator enrollment uses your app's **Enter setup key** option: time-based, SHA-1, 6 digits, 30 seconds.
4. After login, return to the 2FA screen and save the **ten one-use recovery codes**, shown once.
5. Test a fresh login in a private window before requiring 2FA for administrators or all users. A code used for enrollment cannot be reused in the same TOTP timestep.

For email enrollment, first test Nexa Brevo Email, enable **live sending** and its **System** category, and check the CMS account email address. In 2FA policy allow Email, then select that method during enrollment and click **Send / resend email code**. Existing enrolled users reset/re-enroll to switch methods.

## Safety and deployment limits

- One application host/shared lock filesystem only; independent multi-host deployments are not supported.
- Serve the site over HTTPS with secure PHP sessions.
- Removing a required provider blocks login by design. Keep recovery codes and server access.
- Do not regenerate a key to fix decryption errors; restore the original key.
- Network-wide/multisite rollout still needs your developer's staging review. Policy in this release is installation-wide.
- Browser login/remember-me and live Brevo delivery still need testing on your host.

## Verification

- Integration + device/testing suite: **81 checks on CSV + 81 on SQLite**.
- Hosting/external configuration suite: **54 checks on CSV + 54 on SQLite** (includes the original hosting checks).
- New permission-exception checks: **32 additional on CSV + 32 on SQLite**.
- Isolated Apache protection checks: **5 passed**, including private static/config/lock denial and a deliberately disabled-rule control.
- PHP syntax checks passed. Email transport is mocked in the automated suites. No CMS core files were modified.


## New: continue unsecured while testing

The plugin screen now has **Testing pause / continue without this plugin’s 2FA**, above hosting setup. An already logged-in main-site administrator can acknowledge the warning and click **Continue unsecured for testing (24 hours)**. This pauses this provider for **everyone**; normal CMS login, permissions and other providers still apply. A warning stays visible, and the pause expires automatically or can be ended sooner with **Resume configured 2FA policy**. It does not require a working encryption key. It is off by default and is deliberately not a production security feature.

Your reported initial account had no factor enrolled: the original optional/unconfigured policy already allowed ordinary site use. A pause does not repair setup. If you see an account identity error, sign out and back in first. The update now reports session ID/login/realm versus the account the core returned. If it still mismatches, send the error details (no password/key) to your CMS developer. Enrollment and trusted-device issuance will not ignore that mismatch.

## New: do not ask again on this device

Once 2FA is actually working, tick **Trust this device after successful verification** on the challenge page. Default: **30 days**. Each user can save a preferred **1–90 days** in the account's Trusted devices settings or choose a duration for that challenge. A token is created only after a valid factor or recovery code. Use HTTPS and a private device.

**Revoke all my trusted devices** invalidates saved tokens; the site administrator can turn trusted-device acceptance off in policy. Password/role changes, factor reset, expiry and policy changes invalidate older tokens. Normal password login and any other challenge providers still apply. Do not expect this option to fix incomplete 2FA setup.
