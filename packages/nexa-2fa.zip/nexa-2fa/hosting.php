<?php
function nx2_external_path(): string {
    return nx2_network(fn()=>(string)get_setting('nx2_external_config',''));
}
function nx2_normalize_rules(string $s): string { return str_replace(["\r\n","\r"],"\n",$s); }
function nx2_read_generated_config(string $path): array {
    if(!is_file($path)||!is_readable($path)) throw new RuntimeException('The selected configuration file is missing or not readable by PHP.');
    $s=@file_get_contents($path,false,null,0,16385);
    if($s===false || strlen($s)>16384 || !preg_match("/'key'\\s*=>\\s*'([A-Za-z0-9+\\/=]{40,60})'/",$s,$m)) throw new RuntimeException('Configuration is not a recognized generated Nexa 2FA file. No PHP code was executed.');
    if(nx2_normalize_rules($s)!==nx2_normalize_rules(nx2_private_config_source($m[1]))) throw new RuntimeException('Configuration differs from the supported generated format. Ask your developer to review it; no PHP code was executed.');
    $key=base64_decode($m[1],true);
    if($key===false||strlen($key)!==32) throw new RuntimeException('The existing configuration does not contain a valid 32-byte key.');
    return ['version'=>1,'key'=>$m[1],'lock_dir'=>dirname($path).'/locks','protection'=>'browser-probe-v1'];
}
function nx2_outside_public(string $dir): bool {
    $known=0;
    $bases=[(string)($GLOBALS['config']['abs']??''),(string)($_SERVER['DOCUMENT_ROOT']??'')];
    foreach($bases as $raw){$base=$raw!==''?@realpath($raw):false;if($base)$known++;if($base && ($dir===$base||str_starts_with($dir,rtrim($base,DIRECTORY_SEPARATOR).DIRECTORY_SEPARATOR)))return false;}
    return $known>0;
}
function nx2_native_directory(string $input): string {
    if(strlen($input)>4096||preg_match('/[\x00-\x1f]/',$input)||!preg_match('~^(?:/|[A-Za-z]:[\\\\/])~',$input)) throw new RuntimeException('Enter an absolute PHP filesystem directory, not a URL, stream wrapper or relative path.');
    $dir=@realpath($input);
    if($dir===false||!is_dir($dir)) throw new RuntimeException('PHP cannot resolve this directory. It may be absent or blocked by hosting/open_basedir restrictions. FTP access does not prove PHP access.');
    return $dir;
}
function nx2_external_check(string $input): array {
    $dir=nx2_native_directory($input);
    if(!nx2_outside_public($dir)) throw new RuntimeException('External mode requires a directory outside both the CMS and document root.');
    $file=$dir.'/config.php';
    if(is_link($file)||@realpath($file)!==$file)throw new RuntimeException('External config.php must be an actual private file, not a symlink or missing file.');
    $c=nx2_read_generated_config($file);$locks=@realpath($dir.'/locks');
    if(!$locks||!is_dir($locks)||!is_writable($locks)) throw new RuntimeException('The external locks directory is missing or not writable by PHP.');
    if($locks!==$dir.DIRECTORY_SEPARATOR.'locks') throw new RuntimeException('The external locks directory must be a real child directory, not an alias/symlink elsewhere.');
    if((fileperms($file)&0077)!==0) throw new RuntimeException('External config.php must have private permissions 0600. PHP still reports group/other permissions.');
    if((fileperms($dir)&0077)!==0||(fileperms($locks)&0077)!==0) throw new RuntimeException('External private/locks folders must have permissions 0700. PHP still reports group/other permissions.');
    $c['lock_dir']=$locks;$c['protection']='external-private-v1';return $c;
}
function nx2_probe_directory(string $input): array {
    $r=[];
    try{$dir=nx2_native_directory($input);}catch(Throwable $e){return ['Directory access'=>$e->getMessage()];}
    $r['Resolved PHP directory']=$dir;$r['Outside known public roots']=nx2_outside_public($dir)?'yes (check hosting aliases separately)':'NO';
    $r['Directory writable by PHP']=is_writable($dir)?'yes':'no';
    foreach([''=>'Directory','/config.php'=>'config.php','/.htaccess'=>'.htaccess','/locks'=>'locks'] as $suffix=>$label){
        $p=$dir.$suffix;clearstatcache(true,$p);
        $mode=@fileperms($p);$r[$label.' permissions (PHP)']=$mode===false?'unavailable':sprintf('%04o',$mode&0777);
        $uid=@fileowner($p);$r[$label.' owner UID (PHP)']=$uid===false?'unavailable':(string)$uid;
    }
    try{nx2_read_generated_config($dir.'/config.php');$r['Existing key file']='Recognized generated format and valid key length; contents/key not displayed or executed.';}catch(Throwable $e){$r['Existing key file']=$e->getMessage();}
    $file=$dir.'/.nx2-diagnostic-'.bin2hex(random_bytes(12)).'.tmp';$h=false;$other=false;$created=false;
    try{
        $h=@fopen($file,'x+');if(!$h)throw new RuntimeException('Cannot create an exclusive temporary test file.');$created=true;
        $chmod=@chmod($file,0600);$r['Temporary chmod return']=$chmod?'accepted by PHP':'refused by PHP';clearstatcache(true,$file);$r['Temporary file mode after chmod 0600']=sprintf('%04o',fileperms($file)&0777);
        $marker=bin2hex(random_bytes(16));
        if(fwrite($h,$marker)!==strlen($marker)||!fflush($h))throw new RuntimeException('Temporary write/flush failed.');
        rewind($h);$r['Temporary write/read']=stream_get_contents($h)===$marker?'passed':'FAILED';
        if(!function_exists('flock')||!flock($h,LOCK_EX|LOCK_NB))throw new RuntimeException('Cannot acquire an exclusive temporary-file lock.');
        $other=@fopen($file,'r+');if(!$other)throw new RuntimeException('Cannot open a second handle for lock contention test.');
        $second=flock($other,LOCK_EX|LOCK_NB);$r['Lock contention']=$second?'FAILED: competing handle also acquired lock':'passed: competing handle was refused';
        if($second)flock($other,LOCK_UN);flock($h,LOCK_UN);
    }catch(Throwable $e){$r['Temporary file/lock test']=$e->getMessage();}
    finally{if(is_resource($other))fclose($other);if(is_resource($h))fclose($h);if($created&&is_file($file))$r['Temporary cleanup']=@unlink($file)?'passed':'FAILED: remove only this diagnostic file manually';}
    try{nx2_external_check($dir);$r['External-mode safety checks']='passed';}catch(Throwable $e){$r['External-mode safety checks']=$e->getMessage();}
    return $r;
}
function nx2_activate_external(array $ctx,string $input,string $password): void {
    if(!is_user_logged_in()||!in_array($ctx['role'],['admin','super_admin'],true)||$ctx['realm']!=='main'||!empty($_SESSION['nexa_admin_site_id'])||!empty($GLOBALS['nexa_in_site_admin']))throw new RuntimeException('External activation requires a main-site administrator.');
    if(nx2_mode()==='environment')throw new RuntimeException('Environment mode takes precedence. Remove neither variable blindly: preserve the original key and plan migration with your host.');
    if(!nx2_testing_active())throw new RuntimeException('Enable the explicit testing pause and restrict site access before migrating storage.');
    nx2_setup_password($ctx,$password);
    $dir=nx2_native_directory($input);$candidate=nx2_external_check($dir);$newKey=base64_decode($candidate['key'],true);
    $current=nx2_configuration();$oldKey=base64_decode((string)($current['key']??''),true);
    if($oldKey!==false&&strlen($oldKey)===32&&!hash_equals($oldKey,$newKey))throw new RuntimeException('The external key DOES NOT MATCH the current key. Activation refused; no configuration/key was replaced.');
    $paths=[$candidate['lock_dir'].'/nexa-2fa.lock'];
    if(!empty($current['lock_dir'])&&is_dir($current['lock_dir']))$paths[]=$current['lock_dir'].'/nexa-2fa.lock';
    $paths=array_values(array_unique($paths));sort($paths);$handles=[];
    try{
        foreach($paths as $path){$h=@fopen($path,'c');if(!$h)throw new RuntimeException('Cannot open migration lock; original selection unchanged.');$handles[]=$h;
            if(!flock($h,LOCK_EX|LOCK_NB))throw new RuntimeException('A sign-in/storage operation is active. Retry after it completes.');@chmod($path,0600);}
        nx2_network(function()use($newKey,$dir){
            if(table_exists('nx2_accounts'))foreach(query('SELECT sealed FROM nx2_accounts') as $row){
                $raw=base64_decode((string)$row['sealed'],true);
                if($raw===false||strlen($raw)<40)throw new RuntimeException('An existing factor record is invalid. Selection unchanged.');
                $plain=sodium_crypto_secretbox_open(substr($raw,24),substr($raw,0,24),$newKey);
                if($plain===false||!is_array(json_decode($plain,true)))throw new RuntimeException('The external key cannot decrypt every existing factor record. Selection unchanged.');
            }
            loadsettings();$value=$dir.'/config.php';set_setting('nx2_external_config',$value);
            $r=query('SELECT value FROM settings WHERE setting = ?', ['nx2_external_config']);
            if(count($r)!==1||(string)$r[0]['value']!==$value)throw new RuntimeException('External configuration selection could not be confirmed. Inspect settings before retrying.');
        });
    }finally{foreach(array_reverse($handles) as $h){@flock($h,LOCK_UN);fclose($h);}}
}
function nx2_hosting_screen(array $ctx): bool {
    if(!is_user_logged_in()||!in_array($ctx['role'],['admin','super_admin'],true)||$ctx['realm']!=='main'||!empty($_SESSION['nexa_admin_site_id'])||!empty($GLOBALS['nexa_in_site_admin']))return false;
    $handled=false;$report=[];$notice='';$root=(string)($GLOBALS['config']['abs']??'');
    $input=dirname(rtrim($root,'/\\')).'/nexa-2fa-private';
    if(($_SERVER['REQUEST_METHOD']??'')==='POST'&&isset($_POST['nx2_host_action'])){
        $handled=true;
        try{
            if(!nexa_verify_csrf(is_string($_POST['nx2_csrf']??null)?$_POST['nx2_csrf']:''))throw new RuntimeException('Hosting diagnostics security check failed. Reload the page.');
            $input=is_string($_POST['nx2_host_path']??null)?trim($_POST['nx2_host_path']):'';
            if($_POST['nx2_host_action']==='activate'){
                nx2_activate_external($ctx,$input,is_string($_POST['nx2_host_password']??null)?$_POST['nx2_host_password']:'');
                $notice='External configuration selected with the SAME key. No key was regenerated and no private file was deleted. Keep the testing pause on until you verify setup and backed-up files.';
            }elseif($_POST['nx2_host_action']!=='probe')throw new RuntimeException('Unknown hosting action.');
            $report=nx2_probe_directory($input);
        }catch(Throwable $e){$notice=$e instanceof RuntimeException?$e->getMessage():'Hosting operation failed. No secret contents are displayed.';}
    }
    if($notice!=='')echo '<p class="alert alert-info">'.esc_html($notice).'</p>';
    echo '<details'.($handled?' open':'').'><summary><strong>Hosting diagnostics / external private-file mode</strong></summary><p>No key values or file contents are shown. Diagnostics create, lock, read and delete only a randomly named harmless temporary file. No existing file is chmodded, rewritten or removed. PHP may report virtualized modes: a successful FTP listing or blocked CHMOD does not prove PHP access or host isolation.</p><table class="table">';
    $base=['PHP version'=>PHP_VERSION,'PHP effective UID'=>function_exists('posix_geteuid')?(string)posix_geteuid():'not exposed by this host','PHP sodium'=>extension_loaded('sodium')?'available':'MISSING','PHP CMS root'=>$root,'PHP document root'=>(string)($_SERVER['DOCUMENT_ROOT']??''),'open_basedir'=>(string)(ini_get('open_basedir')?:'not set / not reported'),'Configuration mode'=>nx2_mode(),'Current readiness'=>nx2_readiness_label()];
    foreach(array_merge($base,$report) as $k=>$v)echo '<tr><th>'.esc_html($k).'</th><td>'.esc_html((string)$v).'</td></tr>';
    echo '</table><p>Test the current folder by entering '.esc_html(nx2_local_dir()).'. For an external copy, the suggested path below is only a candidate derived from the PHP root—not a confirmed FTP-to-PHP mapping. Adjust it if your host provides a different absolute path. A URL or FTP-only path is not accepted.</p><form method="post">';echo nexa_csrf_field();
    echo '<input type="hidden" name="nx2_csrf" value="'.esc_attr(nexa_csrf_token()).'"><label>Absolute PHP directory containing the existing config.php and locks folder <input class="form-control" name="nx2_host_path" value="'.esc_attr($input).'" required maxlength="4096"></label><p><button class="btn btn-default" name="nx2_host_action" value="probe">Run harmless directory tests</button></p><label>Current password (activation only)<input class="form-control" type="password" name="nx2_host_password" autocomplete="current-password"></label><p>Activation requires an explicit testing pause, PHP access, private 0600 config / 0700 folders, working locks and a matching key. Existing ciphertext is checked. It changes only a keyless settings pointer; it never copies, replaces or generates a key. External mode remains below environment mode in precedence. Restrict site access during migration.</p><button class="btn btn-warning" name="nx2_host_action" value="activate">Validate and use existing external configuration</button></form><p>If PHP cannot access the external folder or the strict checks fail, this update does not bypass the failure. You may continue in clearly labelled testing mode, but not claim 2FA is configured. After successful migration and a secure backup, remove the old in-htdocs private copy with File Manager only when certain it is no longer used. Check that the external directory has no hosting URL alias.</p></details><hr>';
    if(nx2_mode()==='external'&&is_file(nx2_local_dir().'/config.php'))echo '<p class="alert alert-warning">An old in-htdocs key copy still exists. External selection does not erase it. After verifying the external setup and an offline backup, finish migration by removing the old in-htdocs private folder using File Manager; do not remove the active external folder.</p>';
    return $handled;
}
