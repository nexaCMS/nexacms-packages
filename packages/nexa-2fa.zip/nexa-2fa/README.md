# Nexa Two-Factor Authentication 0.5.0

Initial release for **NexaCMS 1.29.1+**. All shipped code lives in `content/plugins/nexa-2fa/`. No CMS core files, login routes, session-grant logic or core patches are included.

## Features

- Authenticator-app TOTP: SHA-1, 6 digits, 30 seconds, a ±1 timestep window, and persisted timestep replay protection.
- Brevo email codes: 6 digits, 5-minute validity, send/resend only on CSRF-protected POST, maximum 5 sends/hour/account and a 60-second cooldown.
- Enforcement chosen by main-site administrator: optional, administrators (`admin` / `super_admin`) required, or all interactive users required.
- Users opt in through the 2FA screen; mandatory accounts enroll through the core's restricted pre-login challenge route.
- Ten one-use 80-bit recovery codes, hashed before storage; account mutations and verification are serialized under a file lock.
- Encrypted factor/attempt state using libsodium secretbox and a deployment key kept outside the database.
- Five verification/management attempts per 15-minute account window, shared across sessions/challenges. Success does not undo TOTP/recovery replay protection. Email resends never reset verification attempts.
- Self-service factor reset/re-enrollment and disabling optional 2FA. Policy changes and factor management require the password plus an enrolled authenticator/recovery code. Email-factor users use a recovery code for these management actions.
- Recent 100 audit events showing account, realm, event and UTC time; approximately 90-day audit retention, cleaned when new events are written.
- Expiring trusted-device cookies, user-selectable 1–90 days, initial default 30, with revoke-all and administrator policy control.
- Explicit 24-hour testing pause for an authenticated main-site administrator, available before encryption setup.
- Core-owned sequenced provider integration and existing-session assurance checks. Ordinary remember-me cookies do not bypass this provider.

TOTP and email OTP are not phishing-resistant. Email OTP depends on mailbox security and timely delivery. There is no SMS, passkey/WebAuthn, QR-code service, or administrator bulk reset in this release. Authenticator setup uses a manual setup key: no enrollment secret is sent to any QR service.

## Before you install

1. Update the canonical CMS to 1.29.1 or a compatible later release.
2. Back up your CMS and database. Use a staging clone first. Keep hosting/FTP access for recovery.
3. Use HTTPS and secure PHP sessions. Configure secure/HTTP-only cookies and sensible SameSite/session settings at your hosting layer. Never expose database stores, session files or backups publicly.
4. This version requires **one application host**, or processes sharing one lock filesystem with reliable `flock()` semantics. Independent multi-host deployments are **not supported**. The lock intentionally serializes operations, including email sends, so this release suits low-volume CMS administration rather than high-volume identity services.
5. PHP sodium is required in addition to the CMS's normal PHP requirements.

## Two hosting modes (no core edits)

### Option A: environment variables — retained from v0.1.0

Ask your host/developer to configure these for the PHP web process using the hosting panel, PHP-FPM pool configuration or equivalent private server configuration:

```
NEXA_2FA_KEY=<base64-encoded random 32-byte key>
NEXA_2FA_LOCK_DIR=/absolute/private/path/nexa-2fa-locks
```

Generate a key privately on the server with `php -r 'echo base64_encode(random_bytes(32)), PHP_EOL;'`. Create the directory outside the CMS and public document root, owned by PHP, permissions **0700**. Back up the key privately. PHP web/CLI environments can differ. The plugin does not read .env files.

If **either** environment variable is present, the complete environment mode takes precedence. Both must then be configured: it never silently mixes an environment key with local paths, or falls back to a local key when an environment override is invalid. Existing environment installations do not need to use the wizard.

### Option B: shared-hosting / File Manager wizard

Designed for hosts where environment variables/private paths outside htdocs are unavailable. Actual compatibility depends on sodium, writable storage, reliable flock and server-enforced .htaccess protection; it has not been tested on the user's live InfinityFree account.

1. Install and open **Two-factor authentication** as the main-site administrator.
2. Under **Option B**, enter your current password and click **Prepare shared-hosting setup**. The wizard creates protection rules and harmless static test files, not an encryption key.
3. Click **Verify protection and finish setup**. Your authenticated same-origin browser must fetch an exact public test marker (HTTP 200), then receive HTTP **403 or 404** with no marker for the matching private probe. This uses your browser's hosting cookies, not a server-side loopback request. Redirects, bot-check pages, network errors, HTTP 200/500 or a leaked marker fail the check.
4. Only after successful browser-reported verification does PHP exclusively create `content/nexa-2fa-private/config.php` with a random key. Setup refuses to replace an existing configuration or generate a new key if existing factor data/armed policy is found.
5. Reload the plugin page to enroll. Use File Manager to back up `content/nexa-2fa-private/config.php` securely, outside the public website. Do not share its contents.

The private directory contains an .htaccess deny policy, a guarded PHP configuration file and a `locks/` subfolder. The .htaccess uses inline error documents to avoid redirect-based error pages where supported. PHP config also exits without output on direct execution. The key is not written to the database or printed on screen. Probe files are non-secret and removed after successful setup. There is no server-side arbitrary-URL fetch and no manual 'ignore failed protection' button.

The setup browser reports the test verdict under the authenticated administrator's CSRF-protected session. This is a deployment check, not independent remote attestation or a defense against an administrator deliberately forging requests. The admin/password confirmation and 10-minute session-bound setup transaction remain required. Local mode allows 0700/0755 directories because web access is controlled by server rules, but refuses group/world-writable directories. If protection cannot be verified, **stop** and ask your host/developer; do not remove the check.

### Backup, updates and changing hosts

Keep the ORIGINAL key/configuration. Losing/changing it without migrating factor records blocks enrolled accounts. Plugin updates replace only the plugin folder; `content/nexa-2fa-private/` is separate and must remain untouched. Do not publish its config in plugin repositories, public backups, support attachments or source control. The local key has filesystem separation from the database, not protection against a compromise that can read both website files and the database.

Changing hosting does not justify generating another key. Environment-to-environment migration uses the same key; local-to-environment migration copies the original local key privately into NEXA_2FA_KEY and configures a new private external lock directory. Removing BOTH overrides selects the stored external configuration if one was activated; otherwise it selects the preserved local configuration. Migration from environment to local on an already enrolled site requires your developer to provision a protected config using the SAME key; the new-install wizard deliberately refuses to regenerate it.

After a host/domain/server change, revalidate .htaccess protection with harmless public/private test markers **before accepting production logins**. Browser verification is recorded at initial setup; runtime readiness checks validate the protection file's contents, not the host's current HTTP behavior. Keep the site restricted during migration. A new server that ignores .htaccess is not safe for local mode merely because its files were copied.

## Install and first test

1. Upload `nexa-2fa-0.5.0.zip` under **Admin → Plugins → Upload Plugin**, or extract `nexa-2fa/` into `content/plugins/`.
2. Keep its **Pre** stage enabled. Open **Two-factor authentication** from the sidebar or Manage shortcut.
3. Configure either hosting mode above and resolve any warning. Reload after wizard completion. The initial policy is Optional with authenticator enrollment enabled.
4. Enter your current password and click **Enable / enroll**.
5. Open Dashboard. Core takes you to its restricted authentication challenge screen.
6. Enter the displayed setup key in your authenticator using the account label shown; choose a time-based account, SHA-1, 6 digits, 30 seconds. Enter a current app code to confirm enrollment.
7. After login, return to **Two-factor authentication** immediately. Save the **ten recovery codes**, displayed once, offline. A reminder appears in the admin footer until you open the screen. They cannot be displayed again; use Reset and re-enroll to create a new set.
8. Test a fresh login in a separate browser/private window, including a recovery code, before enforcing a mandatory policy. The code used for enrollment cannot be reused in the same TOTP timestep: wait for a new app code.
9. As main-site administrator, choose the enforcement policy and allowed new-enrollment methods, reauthenticate, and save. A policy version change invalidates this provider's existing assurance, prompting re-verification on the next protected request.

The core challenge page wraps plugin controls in a CSRF-protected, session-bound form. The plugin does not create a parallel login endpoint, set the core's login flag, or call core finalization directly.

## Enable email codes through Brevo

1. Install and test **Nexa Brevo Email 1.1.x** from this conversation.
2. In Brevo Email enable live sending, select the **System** category, and configure a verified sender and working SMTP/API credentials. Resolve any Brevo IP allow-list restriction first.
3. Ensure each account using email has its correct email set in the CMS user record. The plugin never accepts a posted recipient address for login codes.
4. In 2FA Site policy enable Email as an allowed new-enrollment method; save with management reauthentication.
5. Enroll a new account (or reset your own existing factor), select Email, click **Choose method**, then **Send / resend email code**, and enter the received code.

Each account uses one enrolled factor at a time; recovery codes are the fallback. Allowed methods control new enrollment, not the retroactive revocation of existing factors. Reset/re-enroll to switch factors. This avoids locking out existing users just because an administrator changes the enrollment choices.

Login codes use Brevo's immediate transport even if general email is configured to queue, but do **not** bypass Brevo live-send or System-category policy. Failed delivery never grants access. Provider acceptance is not confirmed inbox delivery. Investigate Brevo activity on failure; the OTP itself is not in the subject or plugin audit log.

Email enrollment binds the factor to the then-current CMS email address. If that email later changes, sending to the new address is blocked: use a recovery code to log in, then reset/re-enroll. This prevents a changed profile address from silently replacing the factor.

## Availability and owner recovery

Once an account opts in or enforcement becomes mandatory, the plugin marks itself required for availability, preserving other providers. This marker intentionally stays even when enforcement returns to Optional: an enrolled account must not silently lose protection if code disappears.

Missing keys, corrupt encrypted records, database errors, or unavailable required providers fail closed for an armed installation. A previously unarmed, optional installation can still sign in to finish initial server setup.

For a lost authenticator or unavailable mailbox, use one recovery code and reset/re-enroll with the password plus a second unused recovery code. There is no password-only web reset for enrolled accounts and no emailed reset bypass.

If all factors/recovery codes are lost, a **trusted server operator** must perform a deliberate recovery:

1. Restrict web access at the hosting layer (maintenance/IP allow-list), and back up the database and key.
2. Disable the plugin and remove only `nexa-2fa` from the active site's `nexa_auth_required_providers` JSON setting, preserving other IDs. Do not assume removing that marker alone bypasses an active provider.
3. In the MAIN database, identify the exact account record via its `identity_key`: SHA-256 of `realm + NUL + user_id + NUL + lowercase(username)`. Use the audited account/realm to avoid resetting the wrong person. Delete **only that account's row** in `nx2_accounts` to revoke its old factor and recovery codes. Existing browser sessions for the recovered account must also be invalidated through trusted session maintenance.
4. Verify the owner's identity offline, keep the site access restriction in place, re-enable the provider with the original encryption key, and re-enroll the recovered account. Mandatory policy remains stored in `nx2_policy`.
5. Restore the availability requirement in each affected site context, test new login/recovery, then reopen access. Document the manual action separately; deleting data directly is outside the plugin audit trail.

Owner recovery deliberately requires server/database authority; it is not an unprotected HTTP route. If you cannot safely perform these operations, have your CMS developer do them. Never edit encrypted `sealed` JSON/ciphertext by hand.

## Database and multisite design

Plugin state uses the main/network database through `nexa_network_call()`, with a settings-cache save/restore around core's database switch. Tables are created lazily:

- `nx2_accounts`: `identity_key`, encrypted `sealed` state (factor secret/email binding, recovery hashes, replay state, attempt/send counters, assurance epoch).
- `nx2_audit`: identity key, realm, user ID, username, event and UTC creation timestamp.
- Setting `nx2_policy`: JSON policy, version, armed availability flag.
- Core setting `nexa_auth_required_providers`: plugin adds its own ID without replacing others.

All queries use the CMS universal helpers with bound values. CSV and SQLite were tested against the uploaded 1.29.1 core. No driver branching is used. MySQL/PostgreSQL/JSON/Array have not been exercised in this release.

Identity includes realm + user ID + username. A subsite's own database identity does not inherit another realm's factor even if IDs/names match. Avoid reusing a deleted account's ID/username without deliberate factor cleanup.

Policy in this initial release is **installation/network-wide**, managed from the main-site admin context, not independent per-subsite policy. Main-site policy management is hidden from site-bound admins. For multisite deployment the provider and its environment/lock/key must be available in **every login context**. Each site persists its own required-provider marker when the armed plugin loads: provision/verify those markers for every site before enforcing/accepting production logins. Installing only in one subsite cannot secure another. Full host/path multisite browser login has not been end-to-end tested; use staging and your developer's rollout review before deploying network-wide.

Plugins with their own authenticated endpoints must call the core's `nexa_auth_enforce_session_assurance('json')` after provider loading and before privileged dispatch, as required by the updated CMS contract. Public endpoints and machine/API credentials do not become protected by interactive 2FA automatically.

## Audit, retention and removal

Audit events include enrollment, verification success/failure, recovery use, email sends/failures, policy changes and self-management changes. Events do not include passwords, TOTP secrets, OTP values, recovery plaintext or IP addresses. Username/realm metadata is personal data: restrict access and retain it according to your policy. Expired audit rows are deleted during new-event writes; inactive installations need a separate maintenance policy.

Do not simply disable/delete this plugin while it is required: login intentionally fails closed. Plan a controlled removal with server access, revoking factor state and required-provider markers as appropriate. Database tables, settings, backups and encrypted records remain after folder deletion. Do not delete tables without a recovery plan.

## Validation and limits of the tests

`verification.txt` records PHP lint, the original 50 integration assertions on each real NexaCMS CSV/SQLite backend, 31 hosting/setup assertions on each backend, and five isolated Apache protection checks, including RFC6238 test vectors, encrypted-state tamper rejection, enrollment, TOTP/recovery/email replay rejection, account limits, email resend/expiry, changed email binding, provider order and concurrent recovery consumption (two PHP processes, exactly one acceptance).

The test email transport is mocked. Tests call the real CMS storage and provider decision functions but are **not** a full HTTP browser authentication suite or independent security audit. Live Brevo delivery, remember-me login through HTTP, PHP-session deployment, all role combinations, reverse proxies and full multisite flows still require staging tests on your host. Do not treat passing unit/integration checks as a guarantee of production security.

Use a synchronized server clock and test backup/recovery before enabling mandatory enforcement. No core files were modified to build this package.


## v0.2.0 change summary

Adds both-mode configuration resolution and the shared-hosting setup wizard without changing factor schema or existing ciphertext. Existing v0.1.0 environment deployments retain the same key/path behavior. Setup prevents new-key generation over existing configuration/factor data. No CMS core files were modified. After updating, refresh the admin page; on InfinityFree-style hosting choose Option B and follow the browser checks.


## v0.3.0: testing pause, trusted devices and account diagnostics

### Continue without 2FA while testing

On the plugin screen expand **Testing pause / continue without this plugin’s 2FA**, acknowledge the warning, and click **Continue unsecured for testing (24 hours)**. This is an explicit **site-wide pause for everyone**, not an administrator-only exception. It does not alter normal CMS password login, permissions or other challenge providers. It is off by default, shows warnings on the plugin screen and in the admin footer, records the last changing administrator/time/expiry in the ordinary `nx2_testing` setting, and expires automatically after 24 hours. Click **Resume configured 2FA policy** sooner when ready. Renew deliberately if more testing time is needed.

This maintenance operation relies on the already authenticated main-site administrator role and CSRF, like plugin administration; it intentionally does not require a working factor/encryption key or a second password confirmation. Therefore a compromised administrator session can pause this provider. It is a consciously unsecured testing tool, not a production security improvement. Keep it off in production. The settings record holds the latest control change, not an append-only audit history before encryption is configured.

The pause is not a public login bypass, break-glass login route, storage-check bypass, or account-identity override. It cannot necessarily rescue an administrator already locked out before reaching the admin screen; server-side recovery still exists for that case. Missing required providers still fail core's availability check even during a stored pause. While paused, enrollment decisions are not forced; resume before testing the actual challenge flow. Existing pending challenges should be cancelled and normal login restarted.

As no users were enrolled on the reported site, its initial optional policy already permits ordinary login without 2FA; the explicit pause makes that testing state visible and time-limited. It does **not** fix the setup mismatch.

### Account identity error

Setup/enrollment still requires an exact account ID and login match from the core's realm lookup. Diagnostics now report the session ID/login/realm and whether core returned no account or a different ID/login. They never include passwords, password hashes or keys. First sign out and back in after CMS updates. If the mismatch persists, send these non-secret details to your CMS developer; this plugin must not guess another account or drop its identity check.

### Trust this device

After server setup, a challenge offers **Trust this device after successful verification**, plus days. Initial default: **30**. Each user can save their preferred **1–90 days** in account settings, authorized by password plus current authenticator/recovery factor. The site administrator can disable trusted-device acceptance in policy. Changing policy invalidates existing tokens through the policy version.

Trust is issued only on successful TOTP, email-code or recovery-code verification, never by ticking a box alone, from a failed attempt, or from testing mode. Each cookie is `__Secure-` prefixed, `Secure`, `HttpOnly`, `SameSite=Lax`, host-only and fixed-expiry; browsers must use HTTPS. It still requires ordinary CMS password/remember-me authentication and does not skip other providers. Issuance completes this provider only; core still handles any remaining providers before login finalization.

Server records store a validator hash inside encrypted factor state, not the raw bearer token. Tokens are bound to account realm/ID/login, live password hash, role, factor epoch and policy version. Expired, revoked, malformed or tampered cookies are rejected. A factor reset or password/role change invalidates prior devices. Up to ten device records are retained per account; issuing another drops the oldest remaining record when needed. No sliding extension is applied.

Use **Revoke all my trusted devices** (password plus factor) to invalidate all stored device records. The old browser cookie may remain until expiry/deletion but is useless after revocation. Sessions whose only second-factor assurance was the trusted cookie are rechecked; sessions already verified with an actual factor retain their normal core assurance. Clearing site cookies forgets this browser but does not revoke a stolen copy; revoke-all does. A stolen trusted token plus usable primary authentication can allow access until expiration/revocation. Never trust public/shared devices.

Encrypted account state gains `trusted_days` and `devices` defaults; no new table/schema migration or new key is needed. Existing factor/config data is preserved. Testing mode adds only `nx2_testing`. Audit events add token issuance/use/revocation and preference changes, never token values.

### Additional testing

31 new assertions per CSV/SQLite backend cover trusted tokens, expiry, validator/password/role/realm/policy binding, record limits, revoke-all, successful issuance vs failure, testing-mode CSRF/acknowledgement/permissions/expiry, and strict identity diagnostics. The new suite includes the original 50 checks: 81 per backend. Hosting configuration suites remain 31 per backend; isolated Apache protection suite remains 5. Total distinct assertions by suite/backend: 229. Live HTTPS cookie persistence and actual browser login still need staging validation on the deployed host.


## v0.4.0: hosting diagnostics and external private-file configuration

### Why this update exists

Some shared hosts reject FTP `SITE CHMOD` with 550 and report virtualized permission bits. The FTP server's listing and PHP's filesystem view are different observations; neither proves the web process can access an external directory. This version diagnoses those differences. It does **not** make 0666 files private or claim to verify host isolation. Strict mode keeps permission checks; v0.5 adds a separately acknowledged local risk exception described below.

Open **Hosting diagnostics / external private-file mode** above the setup area. This panel is available to an already authenticated main-site administrator even when encryption setup/readiness is blocked. It reports PHP version/effective UID when exposed, CMS/document roots, open_basedir, active mode, resolved path, PHP permission/owner reports, readability/format of a known generated config file and strict external-mode checks. It does not print keys, raw file contents or environment secrets.

The harmless directory test creates an exclusively named random temporary file, writes/reads random non-secret bytes, tries chmod on that temporary file only, checks that a second handle cannot acquire its lock, and deletes it. It does not chmod or alter an existing key, .htaccess or folder. The report shows cleanup failures if any; remove only identified diagnostic temporary files in that case. Results are diagnostic, not a permission-bypass switch.

### Test your existing paths

First test the displayed absolute local path to see PHP's view of the files that FTP reports as 0666. Local paths will deliberately fail the *external-mode* location check; their other diagnostics are still useful.

For the outside copy, the form suggests `dirname(PHP CMS root)/nexa-2fa-private`. This is only a candidate, not a claim about FTP mapping. Adjust it to the true absolute filesystem path supplied by your host. An FTP path such as `/nexa-2fa-private` is not necessarily that path. Only the administrator-entered path is tested; the plugin does not scan your account or fetch arbitrary network URLs.

If realpath/read/write tests fail, PHP may be isolated to htdocs even though FTP can list and upload outside it. Stop and ask the host for supported private storage. Keeping the testing pause is an explicitly unsecured option, not a completed 2FA deployment.

### Option C: activate an EXISTING external key file

Precedence is now **environment pair > external settings pointer > local protected file > unconfigured**. A broken selected external file fails closed; the plugin does not fall back silently to an older local copy.

1. Keep a secure backup of the ORIGINAL key/config file. Restrict site access during migration.
2. Enable the explicit 24-hour testing pause to avoid forcing challenges while you move storage.
3. With File Manager/FTP, ensure the outside directory already contains an unchanged copy of the generated `config.php` and a `locks/` child. The plugin never generates a new key for this migration.
4. Run diagnostics on its true PHP path. PHP must be able to read it, the config must be private **0600**, both private/locks directories **0700**, and locks must work. Symlinked config/locks and paths inside known public roots are rejected. Check separately that hosting URL aliases do not expose the selected directory.
5. Enter your current CMS password and click **Validate and use existing external configuration**. The exact account check remains required.
6. Activation checks the candidate key against the existing configured key when readable, and verifies every existing factor record decrypts with that key. Different keys/corrupt ciphertext refuse activation. Existing/new lock paths are held during the pointer update; queued plugin operations recheck lock selection after waiting.
7. Only a keyless path selector, `nx2_external_config`, is stored in the main settings database. No key/config source is copied into the database. Neither private file is deleted or rewritten. Environment overrides still win.
8. Verify the active external mode, preserve an offline/private backup, then complete migration by removing the OLD in-htdocs private key folder with File Manager. A warning reminds you while a known local key copy remains. Do not delete the active external folder. Temporary duplicate key copies retain the old exposure; activation is not an erasure guarantee.
9. Resume policy and test fresh login/recovery/remembered-device behavior before opening production access.

Strict permission checks remain. If the host reports unchangeable 0666 on the external file as well, external activation will refuse. There is no 'assume secure' flag. The separately described v0.5 local permission exception is an explicitly insecure tradeoff, not a claim of secure isolation. Environment and verified local modes remain available with their original requirements.

### File-transfer compatibility and parser hardening

Config and protection files now tolerate LF/CRLF text-transfer conversion while keeping the generated format/rules otherwise unchanged. Generated private configuration is read as a strict recognized data format, **not executed with require/eval**, including when validating an administrator-supplied external path. Unexpected added PHP or changed config structure is refused. This is not a general arbitrary-PHP-config loader; developer-customized files may require review/migration to the supported format. Existing keys and ciphertext do not need to change.

### Validation

Adds 23 external/diagnostic assertions per CSV/SQLite backend (the external suite includes the previous 31 hosting assertions, for 54 per backend). Integration/device/testing remains 81 per backend; the five retained Apache deny-rule checks use unchanged rule directives. Total: **275** assertions across these suites. Includes no-key-output diagnostics, temp cleanup, reported permission checks, non-executing config parser, CRLF, private location/permissions, key mismatch, ciphertext corruption, preserved files, selected-source failure and mode precedence. Permission behavior is exercised on the sandbox filesystem, not InfinityFree's virtualized filesystem. Live external PHP access on the user's host remains to be established through the diagnostic panel.


## v0.5.0: explicit permission-only force enable (experimental)

This version addresses the request to proceed on a host reporting fixed 0666 metadata. It does NOT provide an unconditional force-everything switch. Missing/unreadable keys, sodium, real write/read/locking, core authentication integration, exact account identity and known .htaccess protection remain mandatory. Environment/external modes retain strict permissions.

### What is waived

Only the LOCAL permission-bit tests for the existing key/protection files and private/locks directories can be waived. The files are not chmodded or made private by this option. Another process/co-tenant able to read/write them may compromise factors or expose the private folder despite HTTP denial. Browser denial does not establish filesystem isolation. Prefer strict setup or more suitable hosting. Leave the option off unless you deliberately accept that risk.

### Enable it

1. Back up the original key securely. Update only the plugin folder.
2. Enable **Testing pause / continue without this plugin’s 2FA** first; this prevents forced challenges during approval.
3. Expand **Force enable — permission compatibility only (experimental)**.
4. Enter the current CMS password. An already enrolled account must also provide its current authenticator or an unused recovery code, consistent with normal factor-management controls. No posted user ID or password-only reset replaces an enrolled factor.
5. Check the explicit risk acknowledgement and click **Prepare permission-only force enable**. The server checks actual encryption, temporary write/read, cleanup and competing-handle locking, then reauthenticates under the actual account lock. A fresh pair of harmless public/private browser markers is prepared. No key is generated/replaced and no existing protection file is rewritten.
6. Click **Verify protection and accept permission override**. A same-origin browser must read the exact public marker with HTTP 200 and receive HTTP 403/404 without the marker for the private probe. Redirects, bot checks, HTTP 200/500 and network failures do not pass. The administrator's CSRF-protected browser reports the result, as in initial setup; this is not independent remote attestation.
7. On success the warning **PERMISSION OVERRIDE ACTIVE — NOT STRICTLY SECURED** appears. Readiness says usable with explicit override, not strict success. Reload if viewing a previously rendered report.
8. End the testing pause, keep policy Optional initially, then click Enable/enroll and complete REAL factor enrollment. Save recovery codes and test fresh login before requiring other accounts. The permission exception does not itself enroll anyone, skip password login or grant a second-factor verification.

An acceptance is stored in `nx2_permission_exception` (actor, time, reason, hash binding of canonical local path and normalized generated config/protection contents). It stores no raw key. A changed key/config, path or protection file invalidates the binding; missing/changed protection or unavailable locks still fails readiness even if the setting exists. CRLF-only conversion is normalized consistently. Approval is session/account-bound, expires after ten minutes while pending, and uses CSRF on all UI writes.

After acceptance the exception has **no automatic expiry**, to avoid abruptly locking out enrolled accounts on a host that cannot change permissions. Warnings persist on the plugin screen and admin footer. This is different from the 24-hour testing pause. Moving hosts/paths can invalidate the binding: plan migration/recovery while access is restricted.

### Revoke it

Enable the testing pause, then click **Revoke exception / restore strict permissions**. Revocation is a CSRF-protected main-site administrator operation that restores strict blocking; it never changes/deletes your key. On an unchanged 0666 host, strict readiness will fail again until permissions/hosting are corrected. Keeping the pause on temporarily avoids an abrupt lockout while you fix the host. The setting records the latest acceptance/revocation, not an append-only pre-encryption audit ledger.

### Verification scope

32 additional assertions per CSV/SQLite backend exercise explicit acknowledgement/pause/admin/password/factor requirements, fresh browser-result rejection, token/expiry/identity binding, no key regeneration, metadata warning, configuration change invalidation, hard-check enforcement, actual factor verification after ending pause, and safe revoke. Those tests simulate the authenticated browser's 403 report and simulate bad permission bits on the sandbox filesystem; live InfinityFree browser verification still must pass. No attempt is made to certify the host's tenant isolation. Combined distinct suite/backend checks: **339**, including retained prior Apache protection assertions. No core files were modified.
