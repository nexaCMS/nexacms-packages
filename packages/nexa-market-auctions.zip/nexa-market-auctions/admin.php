<?php
add_menu_item('dashboard',['name'=>'nexa-market-auctions','label'=>' Market Auctions','link'=>'admin.php?plugin_page=nexa-market-auctions'],62);
add_action('nexa_admin',function(){if(($_GET['plugin_page']??'')!=='nexa-market-auctions'||!current_user_can('manage_options'))return;
echo '<h2>Market Auctions</h2><p>Manage this module in <a href="admin.php?plugin_page=nexa-market-setup">Marketplace setup</a>. Disable it there without deleting its data.</p>';});
