<?php
function nm_module_auctions(): bool { return true; }
