<?php
// Module capability is registered by functions.php.
