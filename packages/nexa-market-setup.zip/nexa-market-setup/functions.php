<?php
function nm_setup_apply(array $p): void {
    if(!current_user_can('manage_options'))throw new RuntimeException('Administrator permission required.');
    $e=nm_engine();$name=trim((string)($p['market_name']??''));$cur=(string)($p['currency']??'EUR');$theme=(string)($p['theme']??'market-atlas');
    if(strlen($name)<2||strlen($name)>100||!in_array($cur,['EUR','USD','GBP','CAD','AUD'],true)||!in_array($theme,['market-atlas','market-studio'],true))throw new RuntimeException('Check marketplace name, currency and theme.');
    if($e->one('SELECT id FROM orders LIMIT 1')&&$cur!==$e->setting('currency','EUR'))throw new RuntimeException('Currency cannot be changed after orders exist.');
    $e->tx(function()use($e,$p,$name,$cur){$e->set('name',$name);$e->set('allow_registration',isset($p['allow_registration'])?'1':'0');$e->set('payment_instructions',substr(trim((string)($p['payment_instructions']??'')),0,3000));$e->set('currency',$cur);$e->set('commission_bps',(string)max(0,min(3000,(int)($p['commission_bps']??500))));$e->set('snipe_seconds',(string)max(0,min(600,(int)($p['snipe_seconds']??120))));$e->set('moderation',isset($p['moderation'])?'1':'0');foreach(['auctions','sellers','tracking'] as $m)$e->set('enable_'.$m,isset($p['enable_'.$m])?'1':'0');});
    // Idempotent CMS page creation; never replace existing content.
    foreach(['marketplace'=>['Marketplace','[marketplace]'],'market-account'=>['Marketplace account','[market_account]']] as $slug=>$def){
        $found=null;foreach(get_table('posts')['data'] as $page)if(($page['post_name']??'')===$slug&&($page['post_status']??'')!=='trash'){$found=$page;break;}
        if(!$found){$id=update_table('posts',['post_author'=>$_SESSION['name']??'admin','post_date'=>date('Y-m-d H:i:s'),'post_date_gmt'=>(string)time(),'post_title'=>$def[0],'post_name'=>$slug,'post_content'=>$def[1],'post_status'=>'published','post_type'=>'page','comment_status'=>'closed'],'insert');}else $id=$found['id'];
        set_setting('market_page_'.$slug,(string)$id,'Marketplace page');
    }
    set_setting('template',$theme,'Active theme');
    set_setting('cache_enabled','0','Disabled for live marketplace data');if(function_exists('nexa_cache_purge'))nexa_cache_purge();
    if(function_exists('nexa_shop_create_pages'))nexa_shop_create_pages(false);
    set_setting('shop_currency',$cur,'Shop currency');set_setting('shop_setup_done','1','Managed by marketplace setup');
    $seed=__DIR__.'/catalog.json';if(isset($p['demo'])){if(!is_file($seed))throw new RuntimeException('Demo file missing from setup plugin');$e->seed($seed);}
    $e->set('setup_done','1');$e->audit(get_current_user_id(),'setup.apply',0);
}
