<?php
// A single first-run prompt; activation itself never creates accounts or orders.
if(!empty($GLOBALS['adminarea'])&&current_user_can('manage_options')&&function_exists('nm_engine')&&($_SERVER['REQUEST_METHOD']??'GET')==='GET'&&($_GET['plugin_page']??'')!=='nexa-market-setup'&&empty($_SESSION['nm_setup_prompted'])){
    try{if(nm_engine()->setting('setup_done')!=='1'){$_SESSION['nm_setup_prompted']=1;header('Location: admin.php?plugin_page=nexa-market-setup');exit;}}catch(Throwable $e){error_log($e->getMessage());}
}
