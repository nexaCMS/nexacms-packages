<?php
/** Folio offline page — uses the theme error template. */
include __DIR__ . '/error.php';
