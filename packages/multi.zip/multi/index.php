<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package 8Law Lite
 */

$td = str_replace(baseurl(),"",$theme_dir_url);

get_header();
get_template_part("blog"); 
get_footer();
?>