<?php
// Intentionally empty: functions.php exposes the sender. No network I/O on page load.
