<?php
if (empty($GLOBALS['adminarea'])) return;
add_menu_item('dashboard', ['name'=>'nexa-brevo','class'=>(($_GET['plugin_page'] ?? '') === 'nexa-brevo' ? 'active' : ''),
    'icon'=>'fa fa-envelope fa-fw','label'=>' Brevo Email','link'=>'admin.php?plugin_page=nexa-brevo'], 60);
add_action('nexa_admin', 'nexa_brevo_admin_render');
add_action('di_admin', 'nexa_brevo_admin_render');
add_action('up_admin', 'nexa_brevo_admin_render');
function nexa_brevo_admin_render(): void {
    static $done = false;
    if ($done || empty($GLOBALS['adminarea']) || ($_GET['plugin_page'] ?? '') !== 'nexa-brevo') return;
    $done = true;
    $s = nexa_brevo_settings(); $notice = '';
    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
        if (!nexa_verify_csrf(is_string($_POST['brevo_csrf'] ?? null) ? $_POST['brevo_csrf'] : '')) {
            $notice = 'Security check failed. Reload this page.';
        } else {
            $action = $_POST['brevo_action'] ?? '';
            if ($action === 'save') {
                try {
                    $next = $s;
                    foreach (['from_email','from_name','reply_to','smtp_user','smtp_port','transport'] as $field) {
                        if (!is_string($_POST[$field] ?? null)) throw new RuntimeException('Invalid form input.');
                        $next[$field] = trim($_POST[$field]);
                        if (preg_match('/[\r\n]/', $next[$field]) || strlen($next[$field]) > 320) throw new RuntimeException('Invalid settings value.');
                    }
                    if (!in_array($next['transport'], ['smtp','api'], true) || !in_array($next['smtp_port'], ['587','465','2525'], true)) throw new RuntimeException('Invalid transport or port.');
                    foreach (['from_email','reply_to'] as $field) if ($next[$field] !== '' && !nexa_brevo_address($next[$field])) throw new RuntimeException('Enter valid email addresses.');
                    $next['enabled'] = isset($_POST['enabled']) ? '1' : '0';
                    if ($next['enabled'] === '1' && $next['from_email'] === '') throw new RuntimeException('A sender address is required.');
                    $next['categories'] = [];
                    foreach (['transactional','contact','newsletter','system'] as $category) if (isset($_POST['cat_'.$category])) $next['categories'][] = $category;
                    foreach (['smtp_key','api_key'] as $field) {
                        if (isset($_POST['clear_'.$field])) $next[$field] = '';
                        $value = $_POST[$field] ?? '';
                        if (!is_string($value) || strlen($value) > 2048 || preg_match('/[\r\n]/', $value)) throw new RuntimeException('Invalid credential.');
                        if ($value !== '') $next[$field] = $value;
                    }
                    if (!set_setting('nexa_brevo_config', json_encode($next, JSON_THROW_ON_ERROR))) throw new RuntimeException('Settings could not be saved.');
                    $s = $next; $notice = 'Settings saved.';
                } catch (\Throwable $e) { $notice = $e instanceof RuntimeException ? $e->getMessage() : 'Could not save settings.'; }
            } elseif ($action === 'test') {
                $to = is_string($_POST['test_to'] ?? null) ? trim($_POST['test_to']) : '';
                $result = nexa_brevo_deliver($s, $to, 'NexaCMS Brevo test email', 'Your NexaCMS Brevo transport accepted this test configuration.');
                $notice = $result['message'];
            }
        }
    }
    echo '<div class="container-fluid"><h1>Brevo Email</h1>';
    if ($notice !== '') echo '<div class="alert alert-info">'.esc_html($notice).'</div>';
    echo '<p>Only trusted CMS administrators should access this screen. Existing CMS mail calls require integration; this plugin does not replace PHP mail().</p>';
    echo '<form method="post">'; nexa_csrf_field();
    echo '<input type="hidden" name="brevo_csrf" value="'.esc_attr(nexa_csrf_token()).'"><input type="hidden" name="brevo_action" value="save">';
    echo '<p><label><input type="checkbox" name="enabled" value="1"'.($s['enabled'] === '1' ? ' checked' : '').'> Enable live sending</label></p>';
    echo '<label>Transport <select class="form-control" name="transport">';
    foreach (['smtp'=>'SMTP (encrypted)','api'=>'Brevo API (HTTPS)'] as $v=>$label) echo '<option value="'.$v.'"'.($s['transport'] === $v ? ' selected' : '').'>'.$label.'</option>';
    echo '</select></label>';
    foreach (['from_email'=>'Verified sender email','from_name'=>'Sender name','reply_to'=>'Default reply-to (optional)','smtp_user'=>'SMTP login (from Brevo dashboard)'] as $key=>$label) {
        echo '<div class="form-group"><label>'.esc_html($label).'<input class="form-control" name="'.$key.'" value="'.esc_attr($s[$key]).'" maxlength="320"></label></div>';
    }
    echo '<label>SMTP port <select class="form-control" name="smtp_port">';
    foreach (['587','465','2525'] as $p) echo '<option'.($s['smtp_port'] === $p ? ' selected' : '').'>'.$p.'</option>';
    echo '</select></label><p>Host: smtp-relay.brevo.com. Ports 587/2525 use STARTTLS; 465 uses implicit TLS.</p>';
    foreach (['smtp_key'=>'SMTP key','api_key'=>'API key'] as $key=>$label) {
        $state = nexa_brevo_secret($key, $s) !== '' ? 'Configured' : 'Not configured';
        echo '<div class="form-group"><label>'.esc_html($label).' — '.$state.'<input class="form-control" type="password" name="'.$key.'" value="" autocomplete="new-password"></label> <label><input type="checkbox" name="clear_'.$key.'"> Clear stored key</label></div>';
    }
    echo '<p>Leave key fields blank to keep them. Environment variables override stored keys. Stored keys are not encrypted; prefer server environment variables on production.</p><fieldset><legend>Allowed email categories</legend>';
    foreach (['transactional','contact','newsletter','system'] as $category) echo '<label class="mr-3"><input type="checkbox" name="cat_'.$category.'"'.(in_array($category, (array)$s['categories'], true) ? ' checked' : '').'> '.esc_html(ucfirst($category)).'</label> ';
    echo '</fieldset><p>Categories apply only to messages sent through nexa_brevo_send(). Newsletter consent and unsubscribe handling belong to your newsletter plugin.</p><button class="btn btn-primary" type="submit">Save settings</button></form><hr><h2>Test saved connection</h2><p>A test bypasses the live-send switch and category policy. Save settings first.</p><form method="post">';
    nexa_csrf_field();
    echo '<input type="hidden" name="brevo_csrf" value="'.esc_attr(nexa_csrf_token()).'"><input type="hidden" name="brevo_action" value="test"><label>Recipient <input class="form-control" type="email" name="test_to" required></label> <button class="btn btn-secondary" type="submit">Send test email</button></form></div>';
}
