<?php
/** NexaCMS Brevo transport. No public sending endpoint. */
if (!function_exists('get_setting')) return;

function nexa_brevo_settings(): array {
    $raw = get_setting('nexa_brevo_config');
    $saved = is_array($raw) ? $raw : json_decode((string)$raw, true);
    return array_merge(['enabled'=>'0','transport'=>'smtp','from_email'=>'','from_name'=>'',
        'reply_to'=>'','smtp_user'=>'','smtp_port'=>'587','smtp_key'=>'','api_key'=>'',
        'categories'=>['transactional','contact','newsletter','system']], is_array($saved) ? $saved : []);
}
function nexa_brevo_secret(string $name, array $s): string {
    $env = getenv('NEXA_BREVO_' . strtoupper($name));
    return $env !== false && $env !== '' ? $env : (string)($s[$name] ?? '');
}
function nexa_brevo_address(string $email): bool {
    return !preg_match('/[\r\n]/', $email) && filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}
/** Returns {ok, message, message_id}. category is a trusted caller-supplied policy label. */
function nexa_brevo_send(string $to, string $subject, string $body, array $options = []): array {
    $s = nexa_brevo_settings();
    if ($s['enabled'] !== '1') return ['ok'=>false,'message'=>'Brevo sending is disabled.','message_id'=>''];
    $category = (string)($options['category'] ?? 'transactional');
    if (!in_array($category, (array)$s['categories'], true)) return ['ok'=>false,'message'=>'This email category is disabled.','message_id'=>''];
    return nexa_brevo_deliver($s, $to, $subject, $body, $options);
}
/** Internal transport; admin test uses saved settings without enabling live mail. */
function nexa_brevo_deliver(array $s, string $to, string $subject, string $body, array $options = []): array {
    try {
        $reply = (string)($options['reply_to'] ?? $s['reply_to']);
        if (!nexa_brevo_address($to) || !nexa_brevo_address((string)$s['from_email']) || ($reply !== '' && !nexa_brevo_address($reply)))
            throw new RuntimeException('Invalid recipient, sender, or reply-to address.');
        if ($subject === '' || strlen($subject) > 998 || preg_match('/[\r\n]/', $subject)) throw new RuntimeException('Invalid subject.');
        if (strlen($body) > 1000000) throw new RuntimeException('Message exceeds the 1 MB plugin limit.');
        $html = !empty($options['html']);
        $id = '';
        if ($s['transport'] === 'api') {
            if (!function_exists('curl_init')) throw new RuntimeException('API transport requires PHP cURL.');
            $key = nexa_brevo_secret('api_key', $s);
            if ($key === '' || preg_match('/[\r\n]/', $key)) throw new RuntimeException('Configure a valid API key.');
            $payload = ['sender'=>['email'=>$s['from_email'],'name'=>$s['from_name']],
                'to'=>[['email'=>$to]],'subject'=>$subject, $html ? 'htmlContent' : 'textContent'=>$body];
            if ($reply !== '') $payload['replyTo'] = ['email'=>$reply];
            if ($html) $payload['textContent'] = (string)($options['text'] ?? strip_tags($body));
            $ch = curl_init('https://api.brevo.com/v3/smtp/email');
            curl_setopt_array($ch, [CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload, JSON_THROW_ON_ERROR),
                CURLOPT_HTTPHEADER=>['api-key: '.$key,'Content-Type: application/json','Accept: application/json'],
                CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>30,
                CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2,CURLOPT_FOLLOWLOCATION=>false]);
            $response = curl_exec($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if ($response === false) throw new RuntimeException('API connection failed; check network and TLS configuration. No automatic retry was made.');
            if ($code !== 201) throw new RuntimeException('Brevo API did not accept the request (HTTP '.$code.'). Check credentials, verified sender and account limits.');
            $data = json_decode($response, true);
            $id = (string)($data['messageId'] ?? '');
        } elseif ($s['transport'] === 'smtp') {
            if (!extension_loaded('openssl')) throw new RuntimeException('SMTP requires PHP OpenSSL.');
            $key = nexa_brevo_secret('smtp_key', $s);
            if ($s['smtp_user'] === '' || $key === '') throw new RuntimeException('Configure your SMTP login and SMTP key.');
            if (!in_array((string)$s['smtp_port'], ['587','465','2525'], true)) throw new RuntimeException('Unsupported SMTP port.');
            foreach (['Exception','SMTP','PHPMailer'] as $class) {
                if (!class_exists('PHPMailer\\PHPMailer\\'.$class)) require_once __DIR__.'/vendor/PHPMailer/'.$class.'.php';
            }
            $mail = new \PHPMailer\PHPMailer\PHPMailer(true);
            $mail->isSMTP(); $mail->Host = 'smtp-relay.brevo.com'; $mail->SMTPAuth = true;
            $mail->Username = $s['smtp_user']; $mail->Password = $key;
            $mail->Port = (int)$s['smtp_port']; $mail->SMTPSecure = $mail->Port === 465 ? 'ssl' : 'tls';
            $mail->Timeout = 30; $mail->SMTPDebug = 0; $mail->CharSet = 'UTF-8';
            $mail->setFrom($s['from_email'], $s['from_name']); $mail->addAddress($to);
            if ($reply !== '') $mail->addReplyTo($reply);
            $mail->Subject = $subject; $mail->isHTML($html); $mail->Body = $body;
            if ($html) $mail->AltBody = (string)($options['text'] ?? strip_tags($body));
            try { $mail->send(); } catch (\Throwable $e) {
                throw new RuntimeException('SMTP send failed. Check login, SMTP key, verified sender, port and network. Delivery may be uncertain; check Brevo before retrying.');
            }
            $id = $mail->getLastMessageID();
        } else throw new RuntimeException('Choose SMTP or API.');
        return ['ok'=>true,'message'=>'Accepted by Brevo; inbox delivery is not guaranteed.','message_id'=>$id];
    } catch (\Throwable $e) {
        return ['ok'=>false,'message'=>$e instanceof RuntimeException ? $e->getMessage() : 'Unable to send. Check server configuration.','message_id'=>''];
    }
}
