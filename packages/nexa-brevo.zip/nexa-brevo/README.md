# Nexa Brevo Email 1.0.0

A NexaCMS plugin based on the supplied NexaCMS 1.0 plugin/API documentation. Supports Brevo SMTP and transactional email API; the administrator chooses the transport and permitted categories.

## Install

1. Upload `nexa-brevo.zip` via **Admin → Plugins → Upload Plugin**, or extract `nexa-brevo/` into `content/plugins/`.
2. Keep the plugin's Pre stage enabled. No external requests occur merely from page rendering.
3. Open **Brevo Email** in the sidebar (or Manage on the plugin row).
4. Enter a sender verified in your Brevo account and choose SMTP or API.
5. SMTP: copy the exact SMTP login from Brevo's SMTP & API dashboard and enter its SMTP key. Do not use an API key or account password. Host is fixed to `smtp-relay.brevo.com`; 587/2525 require STARTTLS, 465 uses implicit TLS.
6. API: enter a Brevo API key. Requests use `https://api.brevo.com/v3/smtp/email` over verified HTTPS.
7. Save, send a test to an address you control, then enable live sending and select permitted categories.
8. Integrate the helper with the plugins that generate your mail (example below).

PHP 8.1+ is required (NexaCMS reference targets PHP 8.4). SMTP requires OpenSSL; API requires cURL. Both require a working CA trust store and outbound network access. SMTP includes PHPMailer 6.10.0, with its upstream LGPL license in vendor/PHPMailer/LICENSE. No Composer installation is necessary. Review upstream dependency security updates before production deployment.

## Administrator decides what is sent

The live switch blocks helper calls when disabled. The administrator can permit transactional, contact, newsletter and system categories independently. The trusted calling plugin must supply the correct category. Unlabelled calls default to transactional. Category controls are not user authorization boundaries.

Tests deliberately bypass the live switch and category policy, but use saved credentials and require the admin screen's CSRF check. They send one fixed plain-text message to the entered recipient.

**This plugin does not automatically intercept CMS email.** The provided references expose no global mail transport hook or contact-submit hook. It cannot redefine PHP's built-in `mail()`. Replace mail calls in the relevant CMS/plugin code with the helper below, or adapt the real core mail hook once its source is available. Existing emails remain unchanged until integrated. No public email endpoint is installed.

```php
if (function_exists('nexa_brevo_send')) {
    $result = nexa_brevo_send(
        'customer@example.com',
        'Your order confirmation',
        '<h1>Thank you</h1><p>Your order was received.</p>',
        ['category' => 'transactional', 'html' => true,
         'text' => 'Thank you. Your order was received.']
    );
    if (!$result['ok']) {
        // Show a generic error or record a redacted operational event.
        // Do not silently fall back to mail(): that bypasses admin policy.
    }
}
```

Return shape: `['ok'=>bool, 'message'=>string, 'message_id'=>string]`. `ok` means provider acceptance, not inbox delivery. Categories for contact/newsletter/system work identically. HTML is opt-in; plain text is the default. Optional `reply_to` overrides the configured reply-to; `text` supplies the HTML alternative. One recipient per call. No attachments, bulk campaign management, queue, webhooks or delivery tracking are provided. No automated retries or SMTP/API failover: a timeout can occur after acceptance and blindly retrying could duplicate a message. Check Brevo activity before retrying uncertain sends.

For contact messages, keep a verified site sender; put the validated visitor address in reply-to, never in From. Newsletter integrations must enforce consent, unsubscribe suppression, account limits and rate limits themselves. Sanitize untrusted content before constructing HTML.

## Credential handling and authorization

Prefer server-side environment variables:

```
NEXA_BREVO_SMTP_KEY=your-smtp-key
NEXA_BREVO_API_KEY=your-api-key
```

Use hosting environment controls, not a publicly accessible file. The plugin does not load .env files. Environment credentials override stored credentials; clearing a key in the UI does not clear an environment variable.

Keys can alternatively be entered in the admin UI. They are saved unencrypted in the CMS settings store, never redisplayed, and never placed in logs by this plugin. Limit access to settings tables, flat files, backups and server files. Use HTTPS for admin sessions. No send-log table or email body storage is created.

Admin access follows the documented `$GLOBALS['adminarea']` contract of NexaCMS. The supplied API references do not document a role/capability API: the core must restrict plugin administration to trusted administrators. On sites with non-admin backend users, add the site's real capability check before deploying. This plugin does not invent a role API or claim finer-grained authorization.

## Database and compatibility

Only the documented `get_setting()` / `set_setting()` interface is used. Creates one setting, `nexa_brevo_config` (JSON); no custom tables, driver branching or SQL. Expected to work through all six supported CMS drivers. A settings-only design avoids driver-specific schemas, but full CMS/driver parity still needs testing on your installation.

The admin screen registers nexa_admin, di_admin and up_admin with a render-once guard. It uses standard Bootstrap classes and the documented CSRF/escaping helpers.

## Verification before production

PHP syntax and standalone policy/validation checks are included in the delivered verification results. The full CMS and Brevo credentials were not supplied, so real mail delivery, the core's permissions/session behavior, and CSV/SQLite integration have not been verified. Test those in staging, including disabled categories, bad credentials, both transports and verified sender behavior.

## Removal

Disable all plugin stages to unload it. Delete the folder to remove code. The `nexa_brevo_config` setting remains; remove it via trusted CMS maintenance tools and revoke keys in Brevo if retiring the integration.

## Provider references

- https://www.brevo.com/blog/send-email-php/
- https://developers.brevo.com/reference/sendtransacemail
- https://github.com/PHPMailer/PHPMailer/tree/v6.10.0
